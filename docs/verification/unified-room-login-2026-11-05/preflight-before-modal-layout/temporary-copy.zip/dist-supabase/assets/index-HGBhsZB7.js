import{x as i}from"./index-BNcS-On1.js";import"./react-core-D0zisx0S.js";import"./_commonjsHelpers-CqkleIqs.js";const s=i("PushNotifications",{});export{s as PushNotifications};
