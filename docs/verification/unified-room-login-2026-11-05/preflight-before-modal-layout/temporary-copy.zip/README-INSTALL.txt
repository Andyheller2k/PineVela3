PINEVELA - UNIFIED ROOM LOGIN - 5 NOVEMBER 2026

One login form for email/password or primary email/room PIN.
PIN reset: primary Settings > Manage active room > active room card.
Cumulative web/backend build including notification and image fixes.
Back up dist-supabase and dist-supabase-backend, extract into the existing
pinevela-app root, then restart Node. No new dependencies, SQL, sender
files or environment changes. Preserve .env, the database CA and .security.
The two preceding database migrations are already applied.
The matching Android APK updates PineVela Development without clearing data.
See docs/unified-room-login-2026-11-05.md and the local live
deployment report for actual hosting installation status.
