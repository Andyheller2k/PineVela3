// supabase-system-wipe-worker.ts
import { setTimeout as pause } from "node:timers/promises";
import dotenv from "dotenv";

// supabase/accountAccess.ts
function checkAccountAccess(access, features = [], allowed = true) {
  if (access.banned) {
    const error = new ApiError(403, "This account is banned until " + access.until + ". Reason: " + access.reason, "account_banned");
    Object.assign(error, { accountAccess: access });
    throw error;
  }
  if (!allowed)
    throw new ApiError(401, "Please sign in again to access this account.", "account_signin_required");
  const restriction = access.restrictions.find((r) => r.features.some((f) => features.includes(f)));
  if (restriction) {
    const error = new ApiError(403, "This feature is restricted. Reason: " + restriction.reason, "account_restricted");
    Object.assign(error, { accountAccess: access });
    throw error;
  }
  return access;
}

// supabase/db.ts
import fs from "node:fs";

// resourceSecurity.ts
import { AsyncLocalStorage } from "node:async_hooks";
var ResourceLimitError = class extends Error {
  constructor(status = 429, retryAfter = 60, message = "Too many requests. Please wait before trying again.") {
    super(message);
    this.status = status;
    this.retryAfter = retryAfter;
  }
};
var WorkPool = class {
  constructor(maximum, waiting) {
    this.maximum = maximum;
    this.waiting = waiting;
    this.active = 0;
    this.queue = [];
  }
  async run(work) {
    if (this.active >= this.maximum) {
      if (this.queue.length >= this.waiting) throw new ResourceLimitError(503, 2, "Server processing is busy. Please try again shortly.");
      await new Promise((resolve) => this.queue.push(resolve));
    } else this.active++;
    try {
      return await work();
    } finally {
      const next = this.queue.shift();
      if (next) next();
      else this.active--;
    }
  }
};
var workContext = new AsyncLocalStorage();

// accountSecurity.ts
var SCRYPT_OPTIONS = { N: 32768, r: 8, p: 1, maxmem: 64 * 1024 * 1024 };
var passwordWorkers = new WorkPool(2, 8);

// supabase/notifications.ts
async function notify(client, recipients, notice) {
  const ids = [...new Set(recipients)];
  if (!ids.length) return;
  const { rows: [record] } = await client.query(`insert into public.notifications(sender_context_id,category,title,message,link,admin_message_type)
    values ($1,$2,$3,$4,$5,$6) returning id`, [notice.sender || null, notice.category, notice.title, notice.message, notice.link || null, notice.adminMessageType || null]);
  if (notice.orderId) await client.query("update public.notifications set market_order_id=$2 where id=$1", [record.id, uuid(notice.orderId)]);
  await client.query("insert into public.notification_recipients(notification_id,context_id) select $1,unnest($2::uuid[])", [record.id, ids]);
  await client.query("select pg_notify('pinevela_notifications',id::text) from unnest($1::uuid[]) id", [ids]);
  return record.id;
}

// paystackProvider.ts
var requests = new WorkPool(6, 24);

// supabase/adminSettings.ts
async function requireAdministrator(c, a) {
  if (a.kind !== "admin" || !(await c.query(`select m.context_id from public.admin_memberships m
    join public.account_contexts x on x.id=m.context_id where m.context_id=$1 and m.status='active'
      and x.kind='admin' and x.status='active' and x.auth_user_id=$2
      and m.context_id=private.current_context_id() for share of m,x`, [a.contextId, a.authUserId])).rowCount)
    throw new ApiError(403, "Active administrator access required.");
}

// supabase/managerKeys.ts
var managerKeyError = () => new ApiError(403, "Enter your current manager secret key to authorize this action.", "manager_key_required");
async function requireManagerKeyGrant(client, actor) {
  if (actor.kind !== "manager" || actor.managerKeyVersion === void 0) return;
  const key = await client.query(`select manager_context_id from private.manager_operation_keys where manager_context_id = $1
    and key_hash is not null and version = $2 and (locked_until is null or locked_until <= clock_timestamp()) for share`, [actor.contextId, actor.managerKeyVersion]);
  if (!key.rowCount) throw managerKeyError();
}

// supabase/db.ts
import { Pool, escapeLiteral } from "pg";

// platformSettings.ts
var MAINTENANCE_MESSAGE = "PineVela is temporarily unavailable ,please try again later,thank you.";

// supabase/transactionAdmission.ts
async function takeTransactionAdmission(client, options = {}) {
  await client.query(transactionAdmissionSql(options));
}
function transactionAdmissionSql(options = {}) {
  const statements = [
    options.residenceFreezeChange ? "select pg_advisory_xact_lock(hashtextextended('residence-deletion-freeze',0))" : "select pg_advisory_xact_lock_shared(hashtextextended('residence-deletion-freeze',0))",
    options.accountPolicyChange ? "select pg_advisory_xact_lock(hashtextextended('account-policies',0))" : "select pg_advisory_xact_lock_shared(hashtextextended('account-policies',0))",
    options.maintenanceChange ? "select pg_advisory_xact_lock(hashtextextended('platform-maintenance',0))" : "select pg_advisory_xact_lock_shared(hashtextextended('platform-maintenance',0))"
  ];
  if (options.administrator) statements.push(options.administrator === "read" ? "select pg_advisory_xact_lock_shared(hashtextextended('platform-settings',0))" : "select pg_advisory_xact_lock(hashtextextended('platform-settings',0))");
  return statements.join(";");
}

// supabase/db.ts
var ApiError = class extends Error {
  constructor(status, message, code) {
    super(message);
    this.status = status;
    this.code = code;
  }
};
var SessionExpiredError = class extends ApiError {
  constructor(message, code) {
    super(401, message, code);
    this.sessionExpired = true;
  }
};
var UUID = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;
function uuid(value) {
  if (typeof value !== "string" || !UUID.test(value)) throw new ApiError(400, "Invalid resource ID.");
  return value;
}
function databaseConfig(env = process.env) {
  const raw = env.DATABASE_URL || env.SUPABASE_DB_URL;
  if (!raw || !env.SUPABASE_URL || !env.SUPABASE_DB_CA_FILE) throw new Error("Supabase PostgreSQL and CA configuration are required.");
  const database = new URL(raw), api = new URL(env.SUPABASE_URL);
  if (!["postgres:", "postgresql:"].includes(database.protocol) || api.protocol !== "https:" || !database.hostname.endsWith(".pooler.supabase.com") || (database.port || "5432") !== "5432" || decodeURIComponent(database.username) !== `postgres.${api.hostname.split(".")[0]}` || !database.password || api.username || api.password || api.pathname !== "/" || api.search || api.hash) throw new Error("Supabase project and Session pooler configuration do not match.");
  return {
    host: database.hostname,
    port: 5432,
    database: decodeURIComponent(database.pathname.slice(1)),
    user: decodeURIComponent(database.username),
    password: decodeURIComponent(database.password),
    ssl: { rejectUnauthorized: true, ca: fs.readFileSync(env.SUPABASE_DB_CA_FILE, "utf8") },
    // Keep one established connection across quiet periods; extra burst
    // connections still expire after 30 seconds. The pool remains lazy.
    min: 1,
    max: 8,
    connectionTimeoutMillis: 15e3,
    idleTimeoutMillis: 3e4,
    statement_timeout: 15e3,
    query_timeout: 3e4,
    application_name: "pinevela-supabase"
  };
}
var SupabaseDatabase = class {
  constructor(config = databaseConfig()) {
    this.pool = new Pool(config);
    this.pool.on("connect", (client) => client.on("error", () => console.error("[Database] Client connection failed.")));
    this.pool.on("error", () => console.error("[Database] Idle connection failed."));
  }
  /** One atomic server-owned statement. No transaction-local roles or claims
   * may escape into this path; multi-statement operations use system/actor. */
  async statement(sql, values = []) {
    let client;
    try {
      client = await this.pool.connect();
    } catch {
      throw new ApiError(503, "The database connection is temporarily unavailable. Please retry.", "database_unavailable");
    }
    let discard = false;
    try {
      return await client.query(sql, values);
    } catch (error) {
      discard = true;
      if (error?.message === "Query read timeout" || /^Connection (?:terminated|closed)/i.test(error?.message || "") || /^(?:ECONNRESET|ETIMEDOUT|EPIPE|ECONNREFUSED)$/.test(String(error?.code || "")))
        throw new ApiError(503, "The database connection was interrupted. Refresh your account before retrying.", "database_unavailable");
      throw error;
    } finally {
      client.release(discard);
    }
  }
  async system(work, admission) {
    let client;
    try {
      client = await this.pool.connect();
    } catch {
      throw new ApiError(503, "The database connection is temporarily unavailable. Please retry.", "database_unavailable");
    }
    let discard = false;
    try {
      await client.query("begin isolation level read committed" + (admission ? ";" + transactionAdmissionSql(admission) : ""));
      const result = await work(client);
      await client.query("commit");
      return result;
    } catch (error) {
      const message = error instanceof Error ? error.message : "";
      discard = message === "Query read timeout" || /^Connection (?:terminated|closed)/i.test(message) || /^(?:ECONNRESET|ETIMEDOUT|EPIPE|ECONNREFUSED)$/.test(String(error?.code || ""));
      if (!discard) await client.query("rollback").catch(() => {
        discard = true;
      });
      if (discard) throw new ApiError(503, "The database connection was interrupted. Refresh your account before retrying.", "database_unavailable");
      if (error?.code === "55000" && message === "Reviewed housing records are paused for backup preparation")
        throw new ApiError(409, "These housing records are paused while reviewed backups are prepared. Try again after the administrator resumes them.", "residence_preparation_paused");
      if (error?.code === "55000" && message === "Reviewed wipe records are paused for recovery verification")
        throw new ApiError(409, "These reviewed records are paused for recovery verification. Try again after the founder cancels preparation.", "system_wipe_scope_paused");
      throw error;
    } finally {
      client.release(discard);
    }
  }
  async lockActor(client, actor) {
    const binding = await client.query(`select s.session_id,
        private.account_access(c.id) as access,private.account_session_allowed(c.id,s.session_id) as allowed
        from private.account_sessions s
        join auth.sessions live on live.id = s.session_id and live.user_id = s.auth_user_id
        join public.account_contexts c on c.id = s.active_context_id
        where s.session_id = $1 and s.auth_user_id = $2 and s.active_context_id = $3
          and c.kind = $4 and c.status = 'active' and c.auth_user_id = s.auth_user_id
          and (live.not_after is null or live.not_after > now())
          and private.portal_session_allowed(c.id,s.portal_pin_version)
          and (c.kind <> 'admin' or private.administrator_session_allowed(c.id,s.session_id) and exists (select 1 from public.admin_memberships m where m.context_id = c.id and m.status = 'active'))
          and (c.kind <> 'resident' or exists (select 1 from public.allocations a where a.resident_context_id = c.id and a.ended_at is null))
          and (c.kind <> 'staff' or exists (select 1 from public.staff_assignments a where a.staff_context_id = c.id and a.status = 'active' and a.ended_at is null))
        for share of s, c`, [actor.sessionId, actor.authUserId, actor.contextId, actor.kind]);
    if (!binding.rowCount) throw new SessionExpiredError("Your session is no longer active. Please sign in.");
    checkAccountAccess(binding.rows[0].access, actor.requiredFeatures, binding.rows[0].allowed);
    await requireManagerKeyGrant(client, actor);
  }
  async actor(actor, work) {
    return this.actorTransaction(actor, work, false);
  }
  /** Explicit pure reads only. Shares administrator governance exclusion with
   * other readers; every mutation keeps actor()/authorizedSystem() exclusive. */
  async readActor(actor, work) {
    return this.actorTransaction(actor, work, true);
  }
  async actorTransaction(actor, work, read) {
    return this.system(async (client) => {
      await this.lockActor(client, actor);
      await this.prepareActor(client, actor, true);
      return work(client);
    }, { administrator: actor.kind === "admin" ? read ? "read" : "write" : void 0 });
  }
  /** For narrowly scoped server-owned lifecycle writes that browser roles cannot
   * perform. Rechecks the live actor inside the write transaction; callers must
   * also authorize every target relationship before using this privileged client. */
  async authorizedSystem(actor, kinds, work, maintenanceChange = false, accountPolicyChange = false, residenceFreezeChange = false) {
    return this.authorizedTransaction(actor, kinds, work, maintenanceChange, accountPolicyChange, residenceFreezeChange, false);
  }
  /** Server-selected pure read, never selected by a browser flag or HTTP method.
   * Status helpers which expire reviews/write receipts must stay exclusive. */
  async authorizedRead(actor, kinds, work) {
    return this.authorizedTransaction(actor, kinds, work, false, false, false, true);
  }
  async authorizedTransaction(actor, kinds, work, maintenanceChange, accountPolicyChange, residenceFreezeChange, read) {
    return this.system(async (client) => {
      await this.lockActor(client, actor);
      if (!kinds.includes(actor.kind)) throw new ApiError(403, "This account cannot perform that action.");
      await this.prepareActor(client, actor, false);
      return work(client);
    }, {
      residenceFreezeChange,
      accountPolicyChange,
      maintenanceChange,
      administrator: actor.kind === "admin" ? read ? "read" : "write" : void 0
    });
  }
  async prepareActor(client, actor, scoped) {
    const claims = escapeLiteral(JSON.stringify({ sub: actor.authUserId, session_id: actor.sessionId, role: "authenticated" }));
    const results = await client.query(`select set_config('request.jwt.claims', ${claims}, true);select private.platform_access_allowed() as allowed` + (scoped ? ";set local role pinevela_backend" : ""));
    if (!results[1]?.rows[0]?.allowed)
      throw new ApiError(503, MAINTENANCE_MESSAGE, "platform_maintenance");
  }
  /** Public invitation lifecycle operations use private tables without a bound
   * portal, but still serialize with maintenance transitions. */
  async availableSystem(work) {
    return this.system(async (client) => {
      await takeTransactionAdmission(client);
      if (!(await client.query("select private.platform_available() as available")).rows[0].available)
        throw new ApiError(503, MAINTENANCE_MESSAGE, "platform_maintenance");
      return work(client);
    });
  }
  async publicRows(sql, values = []) {
    return this.system(async (client) => {
      const admission = await client.query("select pg_advisory_xact_lock_shared(hashtextextended('platform-maintenance',0));select private.platform_available() as available");
      if (!admission[1]?.rows[0]?.available)
        throw new ApiError(503, MAINTENANCE_MESSAGE, "platform_maintenance");
      await client.query("set local role pinevela_catalog");
      return (await client.query(sql, values)).rows;
    });
  }
  async close() {
    await this.pool.end();
  }
};

// supabase/adminGovernance.ts
function deniedApprovalKey(grant) {
  if (!grant.allowed) throw new ApiError(grant.locked ? 429 : 403, grant.locked ? "Too many approval-key attempts. Wait 15 minutes." : "Enter your current separate approval key.", grant.locked ? "approval_key_locked" : "approval_key_required");
}
async function requireApprovalGrant(c, a, grant) {
  await requireAdministrator(c, a);
  deniedApprovalKey(grant);
  if (!(await c.query(`select context_id from private.admin_secrets where context_id=$1 and approval_key_hash is not null
    and approval_key_version=$2 and (locked_until is null or locked_until<=clock_timestamp()) for share`, [a.contextId, grant.version])).rowCount)
    throw new ApiError(403, "Your approval authorization changed. Enter your current key again.");
  await c.query("select set_config('pinevela.approval_key_version',$1,true)", [grant.version]);
}

// supabase/systemWipeExecutionRequests.ts
function systemWipeExecutionRequestsEnabled() {
  return process.env.PINEVELA_SYSTEM_WIPE_EXECUTION_REQUESTS === "true";
}

// scripts/lib/system-wipe-recovery.ts
import path4 from "node:path";
import crypto4 from "node:crypto";

// supabase/storageBackup.ts
import fs2 from "node:fs";
import path from "node:path";
import crypto from "node:crypto";

// imageUploadSecurity.ts
import sharp from "sharp";
var MAX_IMAGE_INPUT_BYTES = 20 * 1024 * 1024;
var MAX_IMAGE_OUTPUT_BYTES = 100 * 1024 * 1024;
var imageWorkers = new WorkPool(2, 4);

// supabase/storage.ts
var MEDIA_BUCKET = "pinevela-media";
var MAX_MEDIA_BYTES = 6 * 1024 * 1024;
var isStorageFolderMarker = (value) => /^contexts\/[a-f0-9]{8}(?:-[a-f0-9]{4}){3}-[a-f0-9]{12}\/\.emptyFolderPlaceholder$/.test(value);

// supabase/storageBackup.ts
var uuid2 = /^[a-f0-9]{8}(?:-[a-f0-9]{4}){3}-[a-f0-9]{12}$/;
var digest = /^[a-f0-9]{64}$/;
var objectPath = /^contexts\/([a-f0-9]{8}(?:-[a-f0-9]{4}){3}-[a-f0-9]{12})\/([a-f0-9]{8}(?:-[a-f0-9]{4}){3}-[a-f0-9]{12})\.(png|webp)$/;
var MAX_OBJECTS = 1e4;
var MAX_TOTAL_BYTES = 4 * 1024 * 1024 * 1024;
var MAX_MANIFEST_BYTES = 32 * 1024 * 1024;
var sha = (bytes) => crypto.createHash("sha256").update(bytes).digest("hex");
function canonical(value) {
  if (Array.isArray(value)) return "[" + value.map(canonical).join(",") + "]";
  if (value !== null && typeof value === "object") return "{" + Object.keys(value).sort().map((k) => JSON.stringify(k) + ":" + canonical(value[k])).join(",") + "}";
  const result = JSON.stringify(value);
  if (result === void 0) throw new Error("Unsupported recovery metadata.");
  return result;
}
function storageSnapshotDigest(snapshot) {
  return sha(canonical(snapshot));
}
async function readStorageSnapshot(c) {
  return (await c.query(`select jsonb_build_object(
    'buckets',(select coalesce(jsonb_agg(to_jsonb(t) order by id),'[]'::jsonb) from (select * from storage.buckets order by id limit 501) t),
    'objects',(select coalesce(jsonb_agg(to_jsonb(t) order by bucket_id,name,id),'[]'::jsonb) from (select * from storage.objects order by bucket_id,name,id limit 10001) t),
    'assets',(select coalesce(jsonb_agg(to_jsonb(t) order by id),'[]'::jsonb) from (select * from public.media_assets order by id limit 10001) t),
    'multipartUploads',(select count(*) from storage.s3_multipart_uploads)) as snapshot`)).rows[0].snapshot;
}
function validBinding(b) {
  if (!b || !/^[a-z0-9]{20}$/.test(b.projectRef) || !uuid2.test(b.checkpointId) || !digest.test(b.dumpSha256)) throw new Error("Invalid database recovery binding.");
}
function storageRecoveryObjects(snapshot) {
  if (!snapshot || !Array.isArray(snapshot.buckets) || !Array.isArray(snapshot.objects) || !Array.isArray(snapshot.assets) || snapshot.buckets.length > 500 || snapshot.objects.length > MAX_OBJECTS || snapshot.assets.length > MAX_OBJECTS || snapshot.multipartUploads !== 0 || Buffer.byteLength(canonical(snapshot)) > MAX_MANIFEST_BYTES - 1024 * 1024) throw new Error("Unsupported or unfinished Storage inventory.");
  const bucket = snapshot.buckets.find((b) => b.id === MEDIA_BUCKET);
  if (!bucket || bucket.public !== false) throw new Error("A private PineVela media bucket is required.");
  const assets = /* @__PURE__ */ new Map(), objects = /* @__PURE__ */ new Set();
  let total = 0;
  for (const a of snapshot.assets) {
    const match = typeof a.object_path === "string" ? objectPath.exec(a.object_path) : null;
    if (!match || match[1] !== a.owner_context_id || match[2] !== a.id || a.bucket_id !== MEDIA_BUCKET || !digest.test(a.sha256) || !Number.isSafeInteger(a.byte_size) || a.byte_size < 1 || a.byte_size > MAX_MEDIA_BYTES || assets.has(a.object_path) || !["ready", "reserved", "failed", "removing"].includes(a.state)) throw new Error("Invalid saved media ownership or integrity metadata.");
    assets.set(a.object_path, a);
  }
  const result = snapshot.objects.map((o) => {
    const match = typeof o.name === "string" ? objectPath.exec(o.name) : null;
    const size = typeof o.metadata?.size === "number" ? o.metadata.size : NaN;
    if (o.bucket_id === MEDIA_BUCKET && uuid2.test(o.id) && isStorageFolderMarker(o.name) && size === 0 && o.metadata?.mimetype === "application/octet-stream") {
      if (objects.has(o.name) || assets.has(o.name)) throw new Error("Invalid folder marker recovery metadata.");
      objects.add(o.name);
      return { id: o.id, path: o.name, byte_size: 0, sha256: sha(Buffer.alloc(0)), source: "orphan" };
    }
    if (o.bucket_id !== MEDIA_BUCKET || !uuid2.test(o.id) || !match || objects.has(o.name) || !Number.isSafeInteger(size) || size < 1 || size > MAX_MEDIA_BYTES || o.metadata?.mimetype !== `image/${match[3]}`) throw new Error("Unsupported Storage object; recovery cannot omit it.");
    objects.add(o.name);
    total += size;
    if (total > MAX_TOTAL_BYTES) throw new Error("Storage recovery exceeds the bounded archive capacity.");
    const a = assets.get(o.name);
    if (a && a.byte_size !== size) throw new Error("Storage size differs from the saved media reservation.");
    return { id: match[2], path: o.name, byte_size: size, sha256: a?.sha256, source: a ? "asset" : "orphan" };
  });
  for (const a of assets.values()) if (a.state === "ready" && !objects.has(a.object_path)) throw new Error("Ready media is missing its Storage object.");
  if (new Set(result.map((o) => o.id)).size !== result.length) throw new Error("Storage recovery object IDs are ambiguous.");
  return result;
}
function privateRecoveryDirectory(directory) {
  const s = fs2.lstatSync(directory);
  if (!s.isDirectory() || s.isSymbolicLink() || (s.mode & 63) !== 0) throw new Error("Recovery directory must be private and regular.");
}
function readPrivateRecoveryFile(file, maximum) {
  const fd = fs2.openSync(file, fs2.constants.O_RDONLY | fs2.constants.O_NOFOLLOW);
  try {
    const s = fs2.fstatSync(fd);
    if (!s.isFile() || (s.mode & 63) !== 0 || s.size > maximum) throw new Error("Private bounded recovery file required.");
    const bytes = fs2.readFileSync(fd);
    if (bytes.length !== s.size || bytes.length > maximum) throw new Error("Recovery file changed during reading.");
    return bytes;
  } finally {
    fs2.closeSync(fd);
  }
}
function open(bytes, key, aad) {
  if (bytes.length < 33 || !bytes.subarray(0, 5).equals(Buffer.from("PVSB1"))) throw new Error("Invalid Storage recovery archive.");
  const c = crypto.createDecipheriv("aes-256-gcm", key, bytes.subarray(5, 17));
  c.setAAD(Buffer.from(aad));
  c.setAuthTag(bytes.subarray(-16));
  return Buffer.concat([c.update(bytes.subarray(17, -16)), c.final()]);
}
function manifestAAD(id, b) {
  return "pinevela:storage:manifest:" + id + ":" + canonical(b);
}
function objectAAD(id, b, inventory, e) {
  return "pinevela:storage:object:" + id + ":" + canonical(b) + ":" + inventory + ":" + canonical(e);
}
function verifyDirectory(directory, id, binding, expected, onObject) {
  privateRecoveryDirectory(directory);
  validBinding(binding);
  if (!uuid2.test(id)) throw new Error("Invalid Storage recovery ID.");
  const key = readPrivateRecoveryFile(path.join(directory, "key"), 32);
  if (key.length !== 32) throw new Error("Invalid Storage recovery key.");
  try {
    const bytes = open(readPrivateRecoveryFile(path.join(directory, "manifest.pvsb"), MAX_MANIFEST_BYTES + 33), key, manifestAAD(id, binding));
    let m;
    try {
      m = JSON.parse(bytes.toString());
    } finally {
      bytes.fill(0);
    }
    if (m.version !== 1 || m.id !== id || canonical(m.binding) !== canonical(binding) || m.inventoryDigest !== storageSnapshotDigest(expected) || storageSnapshotDigest(m.snapshot) !== m.inventoryDigest || !Array.isArray(m.entries)) throw new Error("Storage recovery does not match the database checkpoint.");
    const originals = storageRecoveryObjects(expected);
    if (m.entries.length !== originals.length) throw new Error("Incomplete Storage recovery archive.");
    const files = /* @__PURE__ */ new Set(["key", "manifest.pvsb"]);
    let total = 0;
    for (let i = 0; i < originals.length; i++) {
      const e = m.entries[i], o = originals[i];
      if (!e || e.id !== o.id || e.path !== o.path || e.byte_size !== o.byte_size || e.source !== o.source || !digest.test(e.sha256) || o.sha256 && e.sha256 !== o.sha256 || e.file !== o.id + ".pvblob" || files.has(e.file)) throw new Error("Storage recovery object manifest mismatch.");
      files.add(e.file);
      const data = open(readPrivateRecoveryFile(path.join(directory, e.file), MAX_MEDIA_BYTES + 33), key, objectAAD(id, binding, m.inventoryDigest, e));
      try {
        if (data.length !== e.byte_size || sha(data) !== e.sha256) throw new Error("Storage recovery object integrity failed.");
        total += data.length;
        onObject?.(e, data);
      } finally {
        data.fill(0);
      }
    }
    if (fs2.readdirSync(directory).some((f) => !files.has(f))) throw new Error("Unexpected Storage recovery files.");
    return { objects: originals.length, orphanObjects: originals.filter((e) => e.source === "orphan").length, folderMarkers: originals.filter((e) => isStorageFolderMarker(e.path)).length, bytes: total, inventoryDigest: m.inventoryDigest };
  } finally {
    key.fill(0);
  }
}
function verifyStorageBackup(directory, id, binding, snapshot, onObject) {
  privateRecoveryDirectory(directory);
  if (!uuid2.test(id)) throw new Error("Invalid Storage recovery ID.");
  return verifyDirectory(path.join(directory, id + ".pvstorage"), id, binding, snapshot, onObject);
}

// scripts/lib/storage-checkpoint.ts
import fs4 from "node:fs";
import path3 from "node:path";
import crypto3 from "node:crypto";
import { Pool as Pool2 } from "pg";

// scripts/lib/isolated-postgres.ts
import fs3 from "node:fs";
import path2 from "node:path";
import crypto2 from "node:crypto";
import { spawnSync } from "node:child_process";
function privateBytes(file) {
  const stat = fs3.lstatSync(file);
  if (!stat.isFile() || stat.mode & 63) throw new Error("Private regular backup file required.");
  const fd = fs3.openSync(file, fs3.constants.O_RDONLY | fs3.constants.O_NOFOLLOW);
  try {
    return fs3.readFileSync(fd);
  } finally {
    fs3.closeSync(fd);
  }
}
function decryptedCheckpoint(id) {
  if (!/^[0-9a-f-]{36}$/.test(id)) throw new Error("Pass a backup UUID.");
  const directory = path2.resolve(".security/migration-reset"), metadata = JSON.parse(privateBytes(path2.join(directory, id + ".json")).toString());
  if (!metadata.accessControlIncluded || !metadata.sourceSchemas?.includes("private")) throw new Error("Full privilege-aware checkpoint required.");
  const saved = privateBytes(path2.join(directory, id + ".pvpg")), key = privateBytes(path2.join(directory, id + ".key"));
  if (key.length !== 32 || !saved.subarray(0, 5).equals(Buffer.from("PVPG1"))) throw new Error("Invalid encrypted archive.");
  const decipher = crypto2.createDecipheriv("aes-256-gcm", key, saved.subarray(5, 17));
  decipher.setAuthTag(saved.subarray(-16));
  const decrypted = Buffer.concat([decipher.update(saved.subarray(17, -16)), decipher.final()]);
  key.fill(0);
  if (crypto2.createHash("sha256").update(decrypted).digest("hex") !== metadata.dumpSha256) throw new Error("Archive integrity failed.");
  return decrypted;
}
async function withIsolatedBackup(id, work, options = {}) {
  const decrypted = decryptedCheckpoint(id), directory = path2.resolve(".security/migration-reset");
  const root = path2.join("/tmp", "pv-orders-" + crypto2.randomUUID()), cluster = path2.join(root, "postgres");
  fs3.mkdirSync(root, { mode: 448 });
  const env = { ...process.env, PGHOST: root, PGPORT: "6543", PGDATABASE: "postgres", PGUSER: "pv_restore", PGPASSWORD: "", PGSSLMODE: "disable" };
  function command(name, args2, input) {
    const result = spawnSync(path2.join("/usr/lib/postgresql/18/bin", name), args2, { input, env, timeout: 6e4, maxBuffer: 64 * 1024 * 1024 });
    if (result.status !== 0) {
      fs3.writeFileSync(path2.join(directory, id + ".order-test-failure.log"), result.stderr || Buffer.from("Local PostgreSQL command failed."), { mode: 384 });
      throw new Error("Isolated PostgreSQL " + name + " failed; diagnostics saved privately.");
    }
    return result.stdout;
  }
  let started = false;
  try {
    command("initdb", ["-D", cluster, "--username=pv_restore", "--auth-local=trust", "--auth-host=reject", "--no-instructions"]);
    fs3.appendFileSync(path2.join(cluster, "postgresql.conf"), "\nlisten_addresses = ''\nunix_socket_directories = '" + root + "'\nport = 6543\n", { mode: 384 });
    command("pg_ctl", ["-D", cluster, "-l", path2.join(root, "postgres.log"), "-w", "start"]);
    started = true;
    command("psql", ["-X", "-v", "ON_ERROR_STOP=1"], `create schema extensions;
      create extension if not exists "uuid-ossp" with schema extensions;
      create extension if not exists pgcrypto with schema extensions;
      create extension if not exists pg_trgm with schema extensions;
      do $$ declare name text; begin foreach name in array array['anon','authenticated','service_role','authenticator','supabase_auth_admin','supabase_storage_admin','postgres','supabase_admin','pinevela_backend','pinevela_catalog','dashboard_user'] loop
        if not exists(select 1 from pg_roles where rolname=name) then execute format('create role %I nologin',name); end if;
      end loop; end $$; alter role pinevela_catalog nologin noinherit nobypassrls; grant pinevela_catalog to postgres;
    grant authenticated to pinevela_backend; grant pinevela_backend to postgres;`);
    command("pg_restore", ["--dbname=postgres", "--clean", "--if-exists", "--no-owner", "--single-transaction"], decrypted);
    decrypted.fill(0);
    if (options.applicationCheckpoint) {
      const application = decryptedCheckpoint(options.applicationCheckpoint);
      const authFingerprint = () => command("psql", ["-X", "-q", "-t", "-A", "-v", "ON_ERROR_STOP=1"], `select md5(jsonb_build_object(
        'users',(select jsonb_agg(to_jsonb(t) order by id) from auth.users t),
        'identities',(select jsonb_agg(to_jsonb(t) order by id) from auth.identities t),
        'sessions',(select jsonb_agg(to_jsonb(t) order by id) from auth.sessions t))::text);`).toString().trim();
      const before = authFingerprint();
      try {
        command("psql", ["-X", "-v", "ON_ERROR_STOP=1"], "drop schema private cascade; drop schema public cascade; create schema public; create schema private; revoke all on schema private from public;");
        command("pg_restore", ["--dbname=postgres", "--no-owner", "--single-transaction", "--schema=public", "--schema=private"], application);
        const schemaAcl = command("pg_restore", ["--list"], application).toString().split("\n").filter((line) => /\bACL - SCHEMA (public|private)\b/.test(line)).join("\n") + "\n";
        if (!schemaAcl.trim()) throw new Error("Archived application schema privileges required.");
        const aclFile = path2.join(root, "schema-acl.list");
        fs3.writeFileSync(aclFile, schemaAcl, { mode: 384 });
        command("pg_restore", ["--dbname=postgres", "--no-owner", "--single-transaction", "--use-list=" + aclFile], application);
        const storagePolicies = command("pg_restore", ["--list"], application).toString().split("\n").filter((line) => /\bPOLICY storage objects pinevela_owned_object_read\b/.test(line)).join("\n") + "\n";
        if (!storagePolicies.trim()) throw new Error("Archived owned-object policy required.");
        const policyFile = path2.join(root, "storage-policy.list");
        fs3.writeFileSync(policyFile, storagePolicies, { mode: 384 });
        command("pg_restore", ["--dbname=postgres", "--no-owner", "--single-transaction", "--use-list=" + policyFile], application);
        command("psql", ["-X", "-v", "ON_ERROR_STOP=1"], `create trigger pinevela_auth_user_created after insert on auth.users
          for each row execute function private.create_primary_profile();`);
        if (before !== authFingerprint()) throw new Error("Rebased fixture changed genuine Auth records.");
      } finally {
        application.fill(0);
      }
    }
    return await work({ host: root, port: 6543, database: "postgres", user: "pv_restore", password: "", ssl: false, max: 8, connectionTimeoutMillis: 1e4, statement_timeout: 15e3, query_timeout: 3e4 });
  } finally {
    try {
      if (started) command("pg_ctl", ["-D", cluster, "-m", "immediate", "-w", "stop"]);
    } finally {
      decrypted.fill(0);
      fs3.rmSync(root, { recursive: true, force: true });
    }
  }
}

// scripts/lib/storage-checkpoint.ts
function storageArchiveRoot() {
  for (const dir of [".security", ".security/migration-reset"]) privateRecoveryDirectory(path3.resolve(dir));
  const directory = path3.resolve(".security/migration-reset/storage");
  if (!fs4.existsSync(directory)) fs4.mkdirSync(directory, { mode: 448 });
  privateRecoveryDirectory(directory);
  return directory;
}
async function storageCheckpoint(checkpointId, inspect) {
  if (!/^[a-f0-9]{8}(?:-[a-f0-9]{4}){3}-[a-f0-9]{12}$/.test(checkpointId)) throw new Error("Pass the database checkpoint UUID.");
  for (const dir of [".security", ".security/migration-reset"]) privateRecoveryDirectory(path3.resolve(dir));
  const directory = path3.resolve(".security/migration-reset");
  const metadata = JSON.parse(readPrivateRecoveryFile(path3.join(directory, checkpointId + ".json"), 1024 * 1024).toString());
  const rehearsal = JSON.parse(readPrivateRecoveryFile(path3.join(directory, checkpointId + ".restore.json"), 1024 * 1024).toString());
  if (!metadata.accessControlIncluded || !metadata.encrypted || !metadata.decryptedRoundTripVerified || !["auth", "public", "private", "storage"].every((s) => metadata.sourceSchemas?.includes(s)) || !rehearsal.isolatedLocalRestorePassed || rehearsal.archiveSha256 !== metadata.dumpSha256 || metadata.serverSecrets && !rehearsal.serverPinKeyVerified) throw new Error("A fully rehearsed privilege-aware database checkpoint is required.");
  const binding = { projectRef: metadata.projectRef, checkpointId, dumpSha256: metadata.dumpSha256 };
  const snapshot = await withIsolatedBackup(checkpointId, async (config) => {
    const pool = new Pool2(config), client = await pool.connect();
    try {
      return { catalog: await readStorageSnapshot(client), inspection: inspect ? await inspect(client) : void 0 };
    } finally {
      client.release();
      await pool.end();
    }
  });
  return { binding, snapshot: snapshot.catalog, inspection: snapshot.inspection, createdAt: metadata.createdAt };
}
function reconstructStorageBackup(archiveId, binding, snapshot) {
  const temporary = fs4.mkdtempSync(path3.join("/tmp", "pv-storage-restore-"));
  fs4.chmodSync(temporary, 448);
  try {
    return verifyStorageBackup(storageArchiveRoot(), archiveId, binding, snapshot, (entry, bytes) => {
      const file = path3.join(temporary, entry.id + (isStorageFolderMarker(entry.path) ? ".folder-marker" : entry.path.endsWith(".webp") ? ".webp" : ".png")), fd = fs4.openSync(file, fs4.constants.O_CREAT | fs4.constants.O_EXCL | fs4.constants.O_WRONLY | fs4.constants.O_NOFOLLOW, 384);
      try {
        fs4.writeFileSync(fd, bytes);
        fs4.fsyncSync(fd);
      } finally {
        fs4.closeSync(fd);
      }
      const recovered = fs4.readFileSync(file);
      try {
        if (recovered.length !== entry.byte_size || crypto3.createHash("sha256").update(recovered).digest("hex") !== entry.sha256) throw new Error("Reconstructed photograph integrity failed.");
      } finally {
        recovered.fill(0);
      }
    });
  } finally {
    fs4.rmSync(temporary, { recursive: true, force: true });
  }
}

// scripts/lib/system-wipe-recovery.ts
var checked = Symbol("verified-system-wipe-recovery");
async function systemWipeRecoveryPreparation(c, proposalId) {
  const found = (await c.query(`select jsonb_build_object('id',f.id,'proposalId',p.id,'founderId',f.founder_context_id,'createdAt',f.created_at,'state',f.state,'scopeDigest',f.scope_digest,
  'current',private.system_wipe_current(p),'quorum',private.system_wipe_quorum(p.id),'status',p.status,'founderDecision',p.wipe_final_decision)as preparation
  from private.system_wipe_preparations f join public.admin_proposals p on p.id=f.proposal_id where p.id=$1`, [uuid(proposalId)])).rows[0]?.preparation;
  if (!found) throw new ApiError(409, "Start a keyed founder backup preparation first.", "system_wipe_preparation_missing");
  if (found.state !== "active" || found.status !== "approved" || !found.current || !found.quorum || found.founderDecision !== "approve-backup") throw new ApiError(409, "The exact preparation or five-admin founder consent changed.", "system_wipe_preparation_changed");
  const hasPauses = (await c.query("select to_regclass('private.system_wipe_freezes')is not null as present")).rows[0].present;
  const pause2 = hasPauses ? (await c.query("select jsonb_build_object('pausedAt',created_at,'pauseState',state)as pause from private.system_wipe_freezes where preparation_id=$1", [found.id])).rows[0]?.pause : null;
  Object.assign(found, { pausedAt: null, pauseState: null }, pause2 || {});
  return found;
}
async function verifySystemWipeRecoveryFiles(proposalId, checkpointId, storageArchiveId) {
  uuid(proposalId);
  uuid(checkpointId);
  uuid(storageArchiveId);
  const { binding, snapshot, inspection, createdAt } = await storageCheckpoint(checkpointId, async (c) => ({ preparation: await systemWipeRecoveryPreparation(c, proposalId), catalogDigest: (await c.query("select private.residence_recovery_catalog_digest()as digest")).rows[0].digest }));
  const prep = inspection.preparation;
  if (!Number.isFinite(Date.parse(createdAt)) || Date.parse(createdAt) < Date.parse(prep.createdAt) || Date.parse(createdAt) > Date.now()) throw new ApiError(409, "The restored checkpoint must include this actual backup preparation.");
  if (prep.pauseState === "frozen" && Date.parse(createdAt) < Date.parse(prep.pausedAt)) throw new ApiError(409, "The restored checkpoint must include the actual reviewed write pause.");
  const reconstructed = reconstructStorageBackup(storageArchiveId, binding, snapshot);
  const manifest = readPrivateRecoveryFile(path4.join(storageArchiveRoot(), storageArchiveId + ".pvstorage", "manifest.pvsb"), 32 * 1024 * 1024 + 33);
  const evidence = {
    preparation_id: prep.id,
    checkpoint_id: binding.checkpointId,
    storage_archive_id: storageArchiveId,
    project_ref: binding.projectRef,
    dump_sha256: binding.dumpSha256,
    storage_inventory_digest: reconstructed.inventoryDigest,
    native_catalog_digest: inspection.catalogDigest,
    manifest_sha256: crypto4.createHash("sha256").update(manifest).digest("hex"),
    scope_digest: prep.scopeDigest,
    preparation_created_at: prep.createdAt,
    checkpoint_created_at: createdAt,
    objects: reconstructed.objects,
    bytes: reconstructed.bytes
  };
  return Object.freeze({ [checked]: true, preparation: Object.freeze(prep), evidence: Object.freeze(evidence) });
}
async function recordSystemWipeRecovery(c, verified, projectRef) {
  if (verified?.[checked] !== true) throw new ApiError(409, "Actual recovery files must be verified first.");
  if (verified.evidence.project_ref !== projectRef) throw new ApiError(409, "Recovery files belong to another project.");
  await c.query("select pg_advisory_xact_lock(hashtextextended('residence-deletion-freeze',0))");
  await c.query("select pg_advisory_xact_lock(hashtextextended('platform-settings',0))");
  const live = await systemWipeRecoveryPreparation(c, verified.preparation.proposalId);
  if (["id", "founderId", "createdAt", "scopeDigest", "pausedAt", "pauseState"].some((k) => live[k] !== verified.preparation[k])) throw new ApiError(409, "The archived preparation and write pause do not match the current review.");
  if (storageSnapshotDigest(await readStorageSnapshot(c)) !== verified.evidence.storage_inventory_digest || (await c.query("select private.residence_recovery_catalog_digest()as digest")).rows[0].digest !== verified.evidence.native_catalog_digest) throw new ApiError(409, "Storage changed after the checkpoint. Prepare and restore fresh recovery files.");
  const evidence = verified.evidence;
  const normalized = (await c.query("select to_jsonb(r)-'verified_at'as proof from jsonb_populate_record(null::private.system_wipe_recovery_evidence,$1)r", [JSON.stringify(evidence)])).rows[0].proof;
  const saved = (await c.query("select to_jsonb(r)-'verified_at'as proof,verified_at from private.system_wipe_recovery_evidence r where preparation_id=$1", [live.id])).rows[0];
  if (saved) {
    if (canonical(saved.proof) !== canonical(normalized)) throw new ApiError(409, "Different recovery evidence is already recorded for this preparation.");
    return { success: true, noChange: true, preparationId: live.id, verifiedAt: saved.verified_at, executionAvailable: false };
  }
  await c.query("select set_config('pinevela.system_wipe_recovery_checked',$1::jsonb::text,true)", [JSON.stringify(normalized)]);
  const receipt = (await c.query(`insert into private.system_wipe_recovery_evidence(preparation_id,checkpoint_id,storage_archive_id,project_ref,dump_sha256,storage_inventory_digest,native_catalog_digest,manifest_sha256,scope_digest,preparation_created_at,checkpoint_created_at,objects,bytes)
  select preparation_id,checkpoint_id,storage_archive_id,project_ref,dump_sha256,storage_inventory_digest,native_catalog_digest,manifest_sha256,scope_digest,preparation_created_at,checkpoint_created_at,objects,bytes from jsonb_populate_record(null::private.system_wipe_recovery_evidence,$1)returning verified_at`, [JSON.stringify(evidence)])).rows[0];
  const admins = (await c.query("select m.context_id from public.admin_memberships m join public.account_contexts x on x.id=m.context_id where m.status='active' and x.status='active'")).rows.map((r) => r.context_id);
  await notify(c, admins, { category: "admin_governance", title: "System wipe recovery backups verified", message: live.pauseState === "frozen" ? "An operator restored the database including the reviewed write pause and verified actual encrypted Storage bytes. Accounts and history remain. Fresh founder consent is required; operational execution remains disabled." : "An operator restored the database and verified actual encrypted Storage bytes for this exact review. Accounts and history remain. This unpaused snapshot cannot authorize execution.", link: "governance" });
  await c.query("insert into private.audit_events(event_type,resource_type,resource_id)values('system_wipe_recovery_verified','system_wipe_preparation',$1)", [live.id]);
  return { success: true, noChange: false, preparationId: live.id, verifiedAt: receipt.verified_at, executionAvailable: false };
}

// scripts/lib/operational-wipe-execution.ts
async function verifyOperationalWipeExecutionFiles(db2, actor, grant, proposalId) {
  const target = uuid(proposalId);
  const saved = await db2.authorizedSystem(actor, ["admin"], async (c) => {
    await requireApprovalGrant(c, actor, grant);
    if (!(await c.query("select 1 from public.admin_memberships where context_id=$1 and slot=1 and status='active'", [actor.contextId])).rowCount)
      throw new ApiError(403, "Only the current founder may execute reviewed operational closure.");
    const receipt = (await c.query(`select r.checkpoint_id,r.storage_archive_id from private.system_wipe_recovery_evidence r
   join private.system_wipe_preparations f on f.id=r.preparation_id join private.system_wipe_freezes z on z.preparation_id=f.id
   where f.proposal_id=$1 and f.state='active'and z.state='frozen'`, [target])).rows[0];
    if (!receipt) throw new ApiError(409, "A paused scope and its saved verified recovery receipt are required.");
    return receipt;
  });
  return verifySystemWipeRecoveryFiles(target, saved.checkpoint_id, saved.storage_archive_id);
}
async function executeOperationalWipeCore(c, actor, grant, verified, projectRef) {
  await requireApprovalGrant(c, actor, grant);
  if (!(await c.query("select 1 from public.admin_memberships where context_id=$1 and slot=1 and status='active'", [actor.contextId])).rowCount)
    throw new ApiError(403, "Only the current founder can execute reviewed operational closure.");
  await recordSystemWipeRecovery(c, verified, projectRef);
  const authorization = (await c.query(
    `select id from private.system_wipe_execution_authorizations a where preparation_id=$1
  and founder_context_id=$2 and auth_user_id=$3 and session_id=$4 and approval_key_version=$5
  and private.system_wipe_execution_authorization_current(a)order by created_at desc limit 1`,
    [verified.preparation.id, actor.contextId, actor.authUserId, actor.sessionId, grant.version]
  )).rows[0];
  if (!authorization) throw new ApiError(409, "Fresh final founder consent is required.");
  const receipt = (await c.query("select to_jsonb(r)-'verified_at'as proof from private.system_wipe_recovery_evidence r where preparation_id=$1", [verified.preparation.id])).rows[0];
  await c.query("select set_config('pinevela.operational_wipe_confirmation','CLOSE REVIEWED OPERATIONAL PORTALS',true),set_config('pinevela.primary_wipe_recovery_checked',$1::jsonb::text,true)", [JSON.stringify(receipt.proof)]);
  const row = (await c.query("select private.run_operational_wipe($1)as id", [authorization.id])).rows[0];
  return { success: true, executionId: row.id, authIdentitiesRetained: true, historyRetained: true, storageObjectsModified: 0 };
}

// scripts/lib/system-wipe-execution-worker.ts
async function processSystemWipeExecutionRequest(db2, requestId, projectRef) {
  if (!systemWipeExecutionRequestsEnabled()) throw new ApiError(503, "Reviewed wipe execution is not enabled.");
  const id = uuid(requestId), lock = await db2.pool.connect();
  let held = false;
  try {
    held = (await lock.query("select pg_try_advisory_lock(hashtextextended('system-wipe-execution-request:'||$1::text,0))as held", [id])).rows[0].held;
    if (!held) return { success: true, skipped: true };
    const request = (await db2.pool.query("select q.*,private.system_wipe_execution_request_current(q)as current from private.system_wipe_execution_requests q where id=$1", [id])).rows[0];
    if (!request) throw new ApiError(404, "Reviewed wipe request not found.");
    if (request.state === "completed") return { success: true, noChange: true, status: "executed", executionId: request.execution_id };
    if (request.state === "invalidated") return { success: true, skipped: true, status: "invalidated" };
    if (!request.current) return await db2.system(async (c) => {
      await c.query("select pg_advisory_xact_lock(hashtextextended('residence-deletion-freeze',0))");
      await c.query("select pg_advisory_xact_lock(hashtextextended('platform-settings',0))");
      const current = (await c.query("select q.id from private.system_wipe_execution_requests q where id=$1 and state='requested'and not private.system_wipe_execution_request_current(q)for update", [id])).rows[0];
      if (!current) return { success: true, skipped: true };
      if (!systemWipeExecutionRequestsEnabled()) throw new ApiError(503, "Reviewed wipe execution is not enabled.");
      const admins = (await c.query("select m.context_id from public.admin_memberships m join public.account_contexts x on x.id=m.context_id where m.status='active'and x.status='active'")).rows.map((r) => r.context_id);
      const notice = await notify(c, admins, {
        category: "admin_governance",
        title: "Reviewed system wipe request invalidated",
        link: "governance",
        message: "This queued request lost current founder consent and cannot execute. Review the preparation before giving fresh consent."
      });
      await c.query("update private.system_wipe_execution_requests set state='invalidated',terminal_notification_id=$2 where id=$1", [id, notice]);
      await c.query("insert into private.audit_events(event_type,resource_type,resource_id)values('system_wipe_execution_request_invalidated','system_wipe_execution_request',$1)", [id]);
      return { success: true, status: "invalidated" };
    });
    const actor = { authUserId: request.auth_user_id, sessionId: request.session_id, contextId: request.founder_context_id, kind: "admin" };
    const grant = { allowed: true, version: request.approval_key_version };
    const verified = await verifyOperationalWipeExecutionFiles(db2, actor, grant, request.proposal_id);
    return await db2.authorizedSystem(actor, ["admin"], async (c) => {
      const current = (await c.query("select q.*,private.system_wipe_execution_request_current(q)as current from private.system_wipe_execution_requests q where id=$1 for update", [id])).rows[0];
      if (current?.state === "completed") return { success: true, noChange: true, status: "executed", executionId: current.execution_id };
      if (!systemWipeExecutionRequestsEnabled()) throw new ApiError(503, "Reviewed wipe execution is not enabled.");
      if (!current?.current || current.authorization_id !== request.authorization_id) throw new ApiError(409, "The queued consent expired or changed during recovery verification.");
      const result = await executeOperationalWipeCore(c, actor, grant, verified, projectRef);
      await c.query("update private.system_wipe_execution_requests set state='completed',execution_id=$2 where id=$1", [id, result.executionId]);
      return { ...result, status: "executed" };
    }, false, false, true);
  } finally {
    if (held) await lock.query("select pg_advisory_unlock(hashtextextended('system-wipe-execution-request:'||$1::text,0))", [id]).catch(() => void 0);
    lock.release(true);
  }
}

// scripts/lib/residence-worker-batch.ts
import fs5 from "node:fs";
import path5 from "node:path";
import crypto5 from "node:crypto";

// scripts/lib/residence-recovery.ts
var checked2 = Symbol("verified-residence-recovery");

// scripts/lib/residence-storage-worker.ts
var prepared = Symbol("prepared-residence-storage");
var missing = Symbol("observed-residence-storage-absence");

// scripts/lib/residence-worker-batch.ts
function residenceWorkerDiagnostic(error) {
  const root = path5.resolve(".security/migration-reset");
  privateRecoveryDirectory(path5.resolve(".security"));
  privateRecoveryDirectory(root);
  const fd = fs5.openSync(
    path5.join(root, crypto5.randomUUID() + ".residence-worker.log"),
    fs5.constants.O_CREAT | fs5.constants.O_EXCL | fs5.constants.O_WRONLY | fs5.constants.O_NOFOLLOW,
    384
  );
  try {
    fs5.writeFileSync(fd, error instanceof Error ? error.stack || error.message : "Worker failed");
    fs5.fsyncSync(fd);
  } finally {
    fs5.closeSync(fd);
  }
}

// scripts/lib/system-wipe-worker-batch.ts
async function runSystemWipeWorkerBatch(db2, options) {
  const execution = { pending: 0, completed: 0, invalidated: 0, skipped: 0, failed: 0 };
  const result = () => ({ readOnly: !options.execute, stopping: options.signal?.aborted === true, limit: 10, execution, storageObjectsModified: 0 });
  if (options.signal?.aborted) return result();
  if (options.execute && !systemWipeExecutionRequestsEnabled()) throw new ApiError(503, "Reviewed wipe execution is not enabled.");
  const rows = (await db2.pool.query("select id from private.system_wipe_execution_requests where state='requested'order by created_at,id limit 10")).rows;
  execution.pending = rows.length;
  if (options.execute) for (const row of rows) {
    if (options.signal?.aborted) break;
    try {
      const outcome = await processSystemWipeExecutionRequest(db2, row.id, options.projectRef);
      if ("skipped" in outcome || "noChange" in outcome) execution.skipped++;
      else if (outcome.status === "invalidated") execution.invalidated++;
      else execution.completed++;
    } catch (error) {
      residenceWorkerDiagnostic(error);
      execution.failed++;
    }
  }
  return result();
}

// supabase-system-wipe-worker.ts
dotenv.config({ quiet: true });
var args = process.argv.slice(2);
if (args.some((a) => !["--execute", "--watch"].includes(a)) || new Set(args).size !== args.length) {
  console.error("Only --execute and --watch are accepted.");
  process.exit(2);
}
var execute = args.includes("--execute");
var watch = args.includes("--watch");
var stop = new AbortController();
var requestStop = () => {
  if (!stop.signal.aborted) {
    stop.abort();
    console.log(JSON.stringify({ event: "stopping", drainingCurrentJob: true }));
  }
};
process.once("SIGTERM", requestStop);
process.once("SIGINT", requestStop);
var db;
try {
  if (execute && !systemWipeExecutionRequestsEnabled()) throw Error("Reviewed wipe execution is not enabled.");
  db = new SupabaseDatabase();
  if (!(await db.pool.query("select 1 from private.schema_migrations where version='20261014084050'")).rowCount) throw Error("Apply all Supabase migrations before starting the wipe worker.");
  const projectRef = new URL(process.env.SUPABASE_URL).hostname.split(".")[0];
  console.log(JSON.stringify({ event: "started", readOnly: !execute, watch, pollSeconds: 15 }));
  while (!stop.signal.aborted) {
    try {
      const outcome = await runSystemWipeWorkerBatch(db, { execute, projectRef, signal: stop.signal });
      console.log(JSON.stringify({ event: "cycle", ...outcome }));
      if (!watch && outcome.execution.failed) process.exitCode = 1;
    } catch (error) {
      residenceWorkerDiagnostic(error);
      console.error(JSON.stringify({ event: "cycle_failed", diagnosticSavedPrivately: true }));
      if (!watch) process.exitCode = 1;
    }
    if (!watch || stop.signal.aborted) break;
    try {
      await pause(15e3, void 0, { signal: stop.signal });
    } catch (error) {
      if (!stop.signal.aborted) throw error;
    }
  }
} catch (error) {
  residenceWorkerDiagnostic(error);
  console.error(JSON.stringify({ event: "startup_failed", readOnly: !execute, diagnosticSavedPrivately: true }));
  process.exitCode = 1;
} finally {
  await db?.close();
  console.log(JSON.stringify({ event: "stopped", drained: true }));
  process.removeListener("SIGTERM", requestStop);
  process.removeListener("SIGINT", requestStop);
}
