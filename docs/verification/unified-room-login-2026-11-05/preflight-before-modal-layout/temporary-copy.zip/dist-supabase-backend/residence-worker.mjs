// supabase-residence-worker.ts
import { setTimeout as pause } from "node:timers/promises";
import dotenv from "dotenv";

// supabase/accountAccess.ts
function checkAccountAccess(access, features = [], allowed = true) {
  if (access.banned) {
    const error = new ApiError(403, "This account is banned until " + access.until + ". Reason: " + access.reason, "account_banned");
    Object.assign(error, { accountAccess: access });
    throw error;
  }
  if (!allowed)
    throw new ApiError(401, "Please sign in again to access this account.", "account_signin_required");
  const restriction = access.restrictions.find((r) => r.features.some((f) => features.includes(f)));
  if (restriction) {
    const error = new ApiError(403, "This feature is restricted. Reason: " + restriction.reason, "account_restricted");
    Object.assign(error, { accountAccess: access });
    throw error;
  }
  return access;
}

// supabase/db.ts
import fs from "node:fs";

// resourceSecurity.ts
import { AsyncLocalStorage } from "node:async_hooks";
var ResourceLimitError = class extends Error {
  constructor(status = 429, retryAfter = 60, message = "Too many requests. Please wait before trying again.") {
    super(message);
    this.status = status;
    this.retryAfter = retryAfter;
  }
};
var WorkPool = class {
  constructor(maximum, waiting) {
    this.maximum = maximum;
    this.waiting = waiting;
    this.active = 0;
    this.queue = [];
  }
  async run(work) {
    if (this.active >= this.maximum) {
      if (this.queue.length >= this.waiting) throw new ResourceLimitError(503, 2, "Server processing is busy. Please try again shortly.");
      await new Promise((resolve) => this.queue.push(resolve));
    } else this.active++;
    try {
      return await work();
    } finally {
      const next = this.queue.shift();
      if (next) next();
      else this.active--;
    }
  }
};
var workContext = new AsyncLocalStorage();

// accountSecurity.ts
var SCRYPT_OPTIONS = { N: 32768, r: 8, p: 1, maxmem: 64 * 1024 * 1024 };
var passwordWorkers = new WorkPool(2, 8);

// supabase/notifications.ts
async function notify(client, recipients, notice) {
  const ids = [...new Set(recipients)];
  if (!ids.length) return;
  const { rows: [record] } = await client.query(`insert into public.notifications(sender_context_id,category,title,message,link,admin_message_type)
    values ($1,$2,$3,$4,$5,$6) returning id`, [notice.sender || null, notice.category, notice.title, notice.message, notice.link || null, notice.adminMessageType || null]);
  if (notice.orderId) await client.query("update public.notifications set market_order_id=$2 where id=$1", [record.id, uuid(notice.orderId)]);
  await client.query("insert into public.notification_recipients(notification_id,context_id) select $1,unnest($2::uuid[])", [record.id, ids]);
  await client.query("select pg_notify('pinevela_notifications',id::text) from unnest($1::uuid[]) id", [ids]);
  return record.id;
}

// paystackProvider.ts
var requests = new WorkPool(6, 24);

// supabase/adminSettings.ts
async function requireAdministrator(c, a) {
  if (a.kind !== "admin" || !(await c.query(`select m.context_id from public.admin_memberships m
    join public.account_contexts x on x.id=m.context_id where m.context_id=$1 and m.status='active'
      and x.kind='admin' and x.status='active' and x.auth_user_id=$2
      and m.context_id=private.current_context_id() for share of m,x`, [a.contextId, a.authUserId])).rowCount)
    throw new ApiError(403, "Active administrator access required.");
}

// supabase/managerKeys.ts
var managerKeyError = () => new ApiError(403, "Enter your current manager secret key to authorize this action.", "manager_key_required");
async function requireManagerKeyGrant(client, actor) {
  if (actor.kind !== "manager" || actor.managerKeyVersion === void 0) return;
  const key = await client.query(`select manager_context_id from private.manager_operation_keys where manager_context_id = $1
    and key_hash is not null and version = $2 and (locked_until is null or locked_until <= clock_timestamp()) for share`, [actor.contextId, actor.managerKeyVersion]);
  if (!key.rowCount) throw managerKeyError();
}

// supabase/db.ts
import { Pool, escapeLiteral } from "pg";

// platformSettings.ts
var MAINTENANCE_MESSAGE = "PineVela is temporarily unavailable ,please try again later,thank you.";

// supabase/transactionAdmission.ts
async function takeTransactionAdmission(client, options = {}) {
  await client.query(transactionAdmissionSql(options));
}
function transactionAdmissionSql(options = {}) {
  const statements = [
    options.residenceFreezeChange ? "select pg_advisory_xact_lock(hashtextextended('residence-deletion-freeze',0))" : "select pg_advisory_xact_lock_shared(hashtextextended('residence-deletion-freeze',0))",
    options.accountPolicyChange ? "select pg_advisory_xact_lock(hashtextextended('account-policies',0))" : "select pg_advisory_xact_lock_shared(hashtextextended('account-policies',0))",
    options.maintenanceChange ? "select pg_advisory_xact_lock(hashtextextended('platform-maintenance',0))" : "select pg_advisory_xact_lock_shared(hashtextextended('platform-maintenance',0))"
  ];
  if (options.administrator) statements.push(options.administrator === "read" ? "select pg_advisory_xact_lock_shared(hashtextextended('platform-settings',0))" : "select pg_advisory_xact_lock(hashtextextended('platform-settings',0))");
  return statements.join(";");
}

// supabase/db.ts
var ApiError = class extends Error {
  constructor(status, message, code) {
    super(message);
    this.status = status;
    this.code = code;
  }
};
var SessionExpiredError = class extends ApiError {
  constructor(message, code) {
    super(401, message, code);
    this.sessionExpired = true;
  }
};
var UUID = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;
function uuid(value) {
  if (typeof value !== "string" || !UUID.test(value)) throw new ApiError(400, "Invalid resource ID.");
  return value;
}
function databaseConfig(env = process.env) {
  const raw = env.DATABASE_URL || env.SUPABASE_DB_URL;
  if (!raw || !env.SUPABASE_URL || !env.SUPABASE_DB_CA_FILE) throw new Error("Supabase PostgreSQL and CA configuration are required.");
  const database = new URL(raw), api = new URL(env.SUPABASE_URL);
  if (!["postgres:", "postgresql:"].includes(database.protocol) || api.protocol !== "https:" || !database.hostname.endsWith(".pooler.supabase.com") || (database.port || "5432") !== "5432" || decodeURIComponent(database.username) !== `postgres.${api.hostname.split(".")[0]}` || !database.password || api.username || api.password || api.pathname !== "/" || api.search || api.hash) throw new Error("Supabase project and Session pooler configuration do not match.");
  return {
    host: database.hostname,
    port: 5432,
    database: decodeURIComponent(database.pathname.slice(1)),
    user: decodeURIComponent(database.username),
    password: decodeURIComponent(database.password),
    ssl: { rejectUnauthorized: true, ca: fs.readFileSync(env.SUPABASE_DB_CA_FILE, "utf8") },
    // Keep one established connection across quiet periods; extra burst
    // connections still expire after 30 seconds. The pool remains lazy.
    min: 1,
    max: 8,
    connectionTimeoutMillis: 15e3,
    idleTimeoutMillis: 3e4,
    statement_timeout: 15e3,
    query_timeout: 3e4,
    application_name: "pinevela-supabase"
  };
}
var SupabaseDatabase = class {
  constructor(config = databaseConfig()) {
    this.pool = new Pool(config);
    this.pool.on("connect", (client) => client.on("error", () => console.error("[Database] Client connection failed.")));
    this.pool.on("error", () => console.error("[Database] Idle connection failed."));
  }
  /** One atomic server-owned statement. No transaction-local roles or claims
   * may escape into this path; multi-statement operations use system/actor. */
  async statement(sql, values = []) {
    let client;
    try {
      client = await this.pool.connect();
    } catch {
      throw new ApiError(503, "The database connection is temporarily unavailable. Please retry.", "database_unavailable");
    }
    let discard = false;
    try {
      return await client.query(sql, values);
    } catch (error) {
      discard = true;
      if (error?.message === "Query read timeout" || /^Connection (?:terminated|closed)/i.test(error?.message || "") || /^(?:ECONNRESET|ETIMEDOUT|EPIPE|ECONNREFUSED)$/.test(String(error?.code || "")))
        throw new ApiError(503, "The database connection was interrupted. Refresh your account before retrying.", "database_unavailable");
      throw error;
    } finally {
      client.release(discard);
    }
  }
  async system(work, admission) {
    let client;
    try {
      client = await this.pool.connect();
    } catch {
      throw new ApiError(503, "The database connection is temporarily unavailable. Please retry.", "database_unavailable");
    }
    let discard = false;
    try {
      await client.query("begin isolation level read committed" + (admission ? ";" + transactionAdmissionSql(admission) : ""));
      const result = await work(client);
      await client.query("commit");
      return result;
    } catch (error) {
      const message = error instanceof Error ? error.message : "";
      discard = message === "Query read timeout" || /^Connection (?:terminated|closed)/i.test(message) || /^(?:ECONNRESET|ETIMEDOUT|EPIPE|ECONNREFUSED)$/.test(String(error?.code || ""));
      if (!discard) await client.query("rollback").catch(() => {
        discard = true;
      });
      if (discard) throw new ApiError(503, "The database connection was interrupted. Refresh your account before retrying.", "database_unavailable");
      if (error?.code === "55000" && message === "Reviewed housing records are paused for backup preparation")
        throw new ApiError(409, "These housing records are paused while reviewed backups are prepared. Try again after the administrator resumes them.", "residence_preparation_paused");
      if (error?.code === "55000" && message === "Reviewed wipe records are paused for recovery verification")
        throw new ApiError(409, "These reviewed records are paused for recovery verification. Try again after the founder cancels preparation.", "system_wipe_scope_paused");
      throw error;
    } finally {
      client.release(discard);
    }
  }
  async lockActor(client, actor) {
    const binding = await client.query(`select s.session_id,
        private.account_access(c.id) as access,private.account_session_allowed(c.id,s.session_id) as allowed
        from private.account_sessions s
        join auth.sessions live on live.id = s.session_id and live.user_id = s.auth_user_id
        join public.account_contexts c on c.id = s.active_context_id
        where s.session_id = $1 and s.auth_user_id = $2 and s.active_context_id = $3
          and c.kind = $4 and c.status = 'active' and c.auth_user_id = s.auth_user_id
          and (live.not_after is null or live.not_after > now())
          and private.portal_session_allowed(c.id,s.portal_pin_version)
          and (c.kind <> 'admin' or private.administrator_session_allowed(c.id,s.session_id) and exists (select 1 from public.admin_memberships m where m.context_id = c.id and m.status = 'active'))
          and (c.kind <> 'resident' or exists (select 1 from public.allocations a where a.resident_context_id = c.id and a.ended_at is null))
          and (c.kind <> 'staff' or exists (select 1 from public.staff_assignments a where a.staff_context_id = c.id and a.status = 'active' and a.ended_at is null))
        for share of s, c`, [actor.sessionId, actor.authUserId, actor.contextId, actor.kind]);
    if (!binding.rowCount) throw new SessionExpiredError("Your session is no longer active. Please sign in.");
    checkAccountAccess(binding.rows[0].access, actor.requiredFeatures, binding.rows[0].allowed);
    await requireManagerKeyGrant(client, actor);
  }
  async actor(actor, work) {
    return this.actorTransaction(actor, work, false);
  }
  /** Explicit pure reads only. Shares administrator governance exclusion with
   * other readers; every mutation keeps actor()/authorizedSystem() exclusive. */
  async readActor(actor, work) {
    return this.actorTransaction(actor, work, true);
  }
  async actorTransaction(actor, work, read) {
    return this.system(async (client) => {
      await this.lockActor(client, actor);
      await this.prepareActor(client, actor, true);
      return work(client);
    }, { administrator: actor.kind === "admin" ? read ? "read" : "write" : void 0 });
  }
  /** For narrowly scoped server-owned lifecycle writes that browser roles cannot
   * perform. Rechecks the live actor inside the write transaction; callers must
   * also authorize every target relationship before using this privileged client. */
  async authorizedSystem(actor, kinds, work, maintenanceChange = false, accountPolicyChange = false, residenceFreezeChange = false) {
    return this.authorizedTransaction(actor, kinds, work, maintenanceChange, accountPolicyChange, residenceFreezeChange, false);
  }
  /** Server-selected pure read, never selected by a browser flag or HTTP method.
   * Status helpers which expire reviews/write receipts must stay exclusive. */
  async authorizedRead(actor, kinds, work) {
    return this.authorizedTransaction(actor, kinds, work, false, false, false, true);
  }
  async authorizedTransaction(actor, kinds, work, maintenanceChange, accountPolicyChange, residenceFreezeChange, read) {
    return this.system(async (client) => {
      await this.lockActor(client, actor);
      if (!kinds.includes(actor.kind)) throw new ApiError(403, "This account cannot perform that action.");
      await this.prepareActor(client, actor, false);
      return work(client);
    }, {
      residenceFreezeChange,
      accountPolicyChange,
      maintenanceChange,
      administrator: actor.kind === "admin" ? read ? "read" : "write" : void 0
    });
  }
  async prepareActor(client, actor, scoped) {
    const claims = escapeLiteral(JSON.stringify({ sub: actor.authUserId, session_id: actor.sessionId, role: "authenticated" }));
    const results = await client.query(`select set_config('request.jwt.claims', ${claims}, true);select private.platform_access_allowed() as allowed` + (scoped ? ";set local role pinevela_backend" : ""));
    if (!results[1]?.rows[0]?.allowed)
      throw new ApiError(503, MAINTENANCE_MESSAGE, "platform_maintenance");
  }
  /** Public invitation lifecycle operations use private tables without a bound
   * portal, but still serialize with maintenance transitions. */
  async availableSystem(work) {
    return this.system(async (client) => {
      await takeTransactionAdmission(client);
      if (!(await client.query("select private.platform_available() as available")).rows[0].available)
        throw new ApiError(503, MAINTENANCE_MESSAGE, "platform_maintenance");
      return work(client);
    });
  }
  async publicRows(sql, values = []) {
    return this.system(async (client) => {
      const admission = await client.query("select pg_advisory_xact_lock_shared(hashtextextended('platform-maintenance',0));select private.platform_available() as available");
      if (!admission[1]?.rows[0]?.available)
        throw new ApiError(503, MAINTENANCE_MESSAGE, "platform_maintenance");
      await client.query("set local role pinevela_catalog");
      return (await client.query(sql, values)).rows;
    });
  }
  async close() {
    await this.pool.end();
  }
};

// scripts/lib/residence-worker-batch.ts
import fs5 from "node:fs";
import path6 from "node:path";
import crypto7 from "node:crypto";

// supabase/storageBackup.ts
import fs2 from "node:fs";
import path from "node:path";
import crypto2 from "node:crypto";

// supabase/storage.ts
import crypto from "node:crypto";

// imageUploadSecurity.ts
import sharp from "sharp";
var MAX_IMAGE_INPUT_BYTES = 20 * 1024 * 1024;
var MAX_IMAGE_OUTPUT_BYTES = 100 * 1024 * 1024;
var imageWorkers = new WorkPool(2, 4);
var ImageUploadError = class extends Error {
  constructor(status, message) {
    super(message);
    this.status = status;
  }
};
function rasterFormat(bytes) {
  if (bytes.subarray(0, 8).equals(Buffer.from([137, 80, 78, 71, 13, 10, 26, 10]))) return "png";
  if (bytes.length >= 3 && bytes[0] === 255 && bytes[1] === 216 && bytes[2] === 255) return "jpeg";
  if (bytes.length >= 12 && bytes.toString("ascii", 0, 4) === "RIFF" && bytes.toString("ascii", 8, 12) === "WEBP") return "webp";
  return void 0;
}
function rasterContentType(bytes) {
  const format = rasterFormat(bytes);
  if (format !== "png" && format !== "webp") throw new ImageUploadError(415, "Use a processed PNG or WebP photograph.");
  return format === "webp" ? "image/webp" : "image/png";
}

// supabase/storage.ts
var MEDIA_BUCKET = "pinevela-media";
var MAX_MEDIA_BYTES = 6 * 1024 * 1024;
var isStorageFolderMarker = (value) => /^contexts\/[a-f0-9]{8}(?:-[a-f0-9]{4}){3}-[a-f0-9]{12}\/\.emptyFolderPlaceholder$/.test(value);
function storageConfig() {
  const url = new URL(process.env.SUPABASE_URL || "");
  const key = process.env.SUPABASE_SECRET_KEY || process.env.SUPABASE_SERVICE_ROLE_KEY || "";
  if (url.protocol !== "https:" || url.username || url.password || url.pathname !== "/" || url.search || url.hash) throw new Error("A secure Supabase Storage origin is required.");
  if (!key.startsWith("sb_secret_")) {
    let claims;
    try {
      claims = JSON.parse(Buffer.from(key.split(".")[1], "base64url").toString());
    } catch {
    }
    if (claims?.role !== "service_role") throw new Error("A server-only Supabase secret or service-role key is required.");
  }
  return { url: url.origin, key, legacy: !key.startsWith("sb_secret_") };
}
async function readBounded(response, maximum) {
  if (!response.body || Number(response.headers.get("content-length") || 0) > maximum) throw new ApiError(503, "Storage returned an unsupported response.");
  const reader = response.body.getReader(), chunks = [];
  let size = 0;
  try {
    for (; ; ) {
      const part = await reader.read();
      if (part.done) break;
      size += part.value.length;
      if (size > maximum) throw new ApiError(503, "Storage returned an unsupported response.");
      chunks.push(Buffer.from(part.value));
    }
    return Buffer.concat(chunks, size);
  } finally {
    await reader.cancel().catch(() => void 0);
    reader.releaseLock();
  }
}
var SupabaseStorage = class {
  constructor() {
    this.operations = new WorkPool(4, 8);
  }
  path(value, folderMarker = false) {
    if (!/^contexts\/[a-f0-9]{8}(?:-[a-f0-9]{4}){3}-[a-f0-9]{12}\/[a-f0-9]{8}(?:-[a-f0-9]{4}){3}-[a-f0-9]{12}\.(?:png|webp)$/.test(value) && !(folderMarker && isStorageFolderMarker(value))) throw new ApiError(400, "Invalid photograph path.");
    return `${MEDIA_BUCKET}/${value}`;
  }
  async request(route, options, maximum, allowMissingObject = false, timeoutMs = 2e4) {
    if (!Number.isInteger(timeoutMs) || timeoutMs < 1e3 || timeoutMs > 6e4) throw new ApiError(503, "Invalid Storage operation deadline.");
    const config = storageConfig();
    return this.operations.run(async () => {
      let response;
      try {
        response = await fetch(`${config.url}/storage/v1${route}`, {
          ...options,
          headers: { apikey: config.key, ...config.legacy ? { Authorization: `Bearer ${config.key}` } : {}, ...options.headers },
          signal: AbortSignal.timeout(timeoutMs),
          redirect: "error",
          cache: "no-store"
        });
        const bytes = await readBounded(response, maximum);
        if (!response.ok && allowMissingObject && [400, 404].includes(response.status)) {
          let detail;
          try {
            detail = JSON.parse(bytes.toString());
          } catch {
          }
          if (Number(detail?.statusCode) === 404 && (detail?.code === "NoSuchKey" || detail?.error === "not_found" && detail?.message === "Object not found"))
            return { bytes, contentType: response.headers.get("content-type"), missing: true };
        }
        if (!response.ok) throw new ApiError(503, "Photograph storage is temporarily unavailable.", `storage_http_${response.status}`);
        return { bytes, contentType: response.headers.get("content-type") };
      } catch (error) {
        if (error instanceof ApiError) throw error;
        throw new ApiError(503, "Photograph storage is temporarily unavailable.", error instanceof Error && error.name === "TimeoutError" ? "storage_timeout" : "storage_transport");
      }
    });
  }
  async upload(path7, bytes) {
    if (!bytes.length || bytes.length > MAX_MEDIA_BYTES) throw new ApiError(413, "The processed photograph must be at most 6MB.");
    const contentType = rasterContentType(bytes);
    if (!path7.endsWith(contentType === "image/webp" ? ".webp" : ".png")) throw new ApiError(400, "Photograph format does not match its path.");
    await this.request(`/object/${this.path(path7)}`, { method: "POST", headers: { "Content-Type": contentType, "x-upsert": "false" }, body: new Uint8Array(bytes) }, 65536);
  }
  async download(path7, expected) {
    if (typeof expected.sha256 !== "string" || !/^[a-f0-9]{64}$/.test(expected.sha256)) throw new ApiError(503, "Photograph integrity metadata is required.");
    this.path(path7);
    return this.downloadForBackup(path7, expected);
  }
  /** Recovery also includes orphan objects left by interrupted uploads. Their
   * size comes from the saved Storage catalog; the archive records their digest.
   * This is server-only and does not authorize a browser download. */
  async downloadForBackup(path7, expected, timeoutMs = 2e4) {
    if (isStorageFolderMarker(path7) && expected.byte_size === 0) {
      const emptyDigest = crypto.createHash("sha256").update(Buffer.alloc(0)).digest("hex");
      if (expected.sha256 !== void 0 && expected.sha256 !== emptyDigest) throw new ApiError(503, "Invalid folder marker recovery metadata.");
      const result2 = await this.request(`/object/authenticated/${this.path(path7, true)}`, { method: "GET" }, 1, false, timeoutMs);
      if (result2.bytes.length !== 0 || result2.contentType?.split(";")[0] !== "application/octet-stream") throw new ApiError(503, "Folder marker integrity could not be verified.");
      return result2.bytes;
    }
    if (!Number.isSafeInteger(expected.byte_size) || expected.byte_size < 1 || expected.byte_size > MAX_MEDIA_BYTES || expected.sha256 !== void 0 && !/^[a-f0-9]{64}$/.test(expected.sha256)) throw new ApiError(503, "Invalid photograph recovery metadata.");
    const result = await this.request(`/object/authenticated/${this.path(path7)}`, { method: "GET" }, MAX_MEDIA_BYTES, false, timeoutMs);
    const contentType = path7.endsWith(".webp") ? "image/webp" : "image/png";
    if (result.contentType?.split(";")[0] !== contentType || result.bytes.length !== expected.byte_size || rasterContentType(result.bytes) !== contentType || expected.sha256 !== void 0 && crypto.createHash("sha256").update(result.bytes).digest("hex") !== expected.sha256) throw new ApiError(503, "Photograph integrity could not be verified.");
    return result.bytes;
  }
  async remove(path7) {
    this.path(path7);
    await this.request(`/object/${MEDIA_BUCKET}`, { method: "DELETE", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ prefixes: [path7] }) }, 65536);
  }
  /** Only an explicit provider NoSuchKey is absence. Auth, route, bucket and
   * transport failures remain failures, including other 404 responses. */
  async objectInfo(path7) {
    const result = await this.request(`/object/info/${this.path(path7)}`, { method: "GET" }, 65536, true);
    if ("missing" in result && result.missing) return null;
    let value;
    try {
      value = JSON.parse(result.bytes.toString());
    } catch {
    }
    if (!value || typeof value !== "object" || Array.isArray(value) || typeof value.id !== "string")
      throw new ApiError(503, "Photograph metadata could not be verified.");
    return value;
  }
};

// supabase/storageBackup.ts
var uuid2 = /^[a-f0-9]{8}(?:-[a-f0-9]{4}){3}-[a-f0-9]{12}$/;
var digest = /^[a-f0-9]{64}$/;
var objectPath = /^contexts\/([a-f0-9]{8}(?:-[a-f0-9]{4}){3}-[a-f0-9]{12})\/([a-f0-9]{8}(?:-[a-f0-9]{4}){3}-[a-f0-9]{12})\.(png|webp)$/;
var MAX_OBJECTS = 1e4;
var MAX_TOTAL_BYTES = 4 * 1024 * 1024 * 1024;
var MAX_MANIFEST_BYTES = 32 * 1024 * 1024;
var sha = (bytes) => crypto2.createHash("sha256").update(bytes).digest("hex");
function canonical(value) {
  if (Array.isArray(value)) return "[" + value.map(canonical).join(",") + "]";
  if (value !== null && typeof value === "object") return "{" + Object.keys(value).sort().map((k) => JSON.stringify(k) + ":" + canonical(value[k])).join(",") + "}";
  const result = JSON.stringify(value);
  if (result === void 0) throw new Error("Unsupported recovery metadata.");
  return result;
}
function storageSnapshotDigest(snapshot) {
  return sha(canonical(snapshot));
}
async function readStorageSnapshot(c) {
  return (await c.query(`select jsonb_build_object(
    'buckets',(select coalesce(jsonb_agg(to_jsonb(t) order by id),'[]'::jsonb) from (select * from storage.buckets order by id limit 501) t),
    'objects',(select coalesce(jsonb_agg(to_jsonb(t) order by bucket_id,name,id),'[]'::jsonb) from (select * from storage.objects order by bucket_id,name,id limit 10001) t),
    'assets',(select coalesce(jsonb_agg(to_jsonb(t) order by id),'[]'::jsonb) from (select * from public.media_assets order by id limit 10001) t),
    'multipartUploads',(select count(*) from storage.s3_multipart_uploads)) as snapshot`)).rows[0].snapshot;
}
function validBinding(b) {
  if (!b || !/^[a-z0-9]{20}$/.test(b.projectRef) || !uuid2.test(b.checkpointId) || !digest.test(b.dumpSha256)) throw new Error("Invalid database recovery binding.");
}
function storageRecoveryObjects(snapshot) {
  if (!snapshot || !Array.isArray(snapshot.buckets) || !Array.isArray(snapshot.objects) || !Array.isArray(snapshot.assets) || snapshot.buckets.length > 500 || snapshot.objects.length > MAX_OBJECTS || snapshot.assets.length > MAX_OBJECTS || snapshot.multipartUploads !== 0 || Buffer.byteLength(canonical(snapshot)) > MAX_MANIFEST_BYTES - 1024 * 1024) throw new Error("Unsupported or unfinished Storage inventory.");
  const bucket = snapshot.buckets.find((b) => b.id === MEDIA_BUCKET);
  if (!bucket || bucket.public !== false) throw new Error("A private PineVela media bucket is required.");
  const assets = /* @__PURE__ */ new Map(), objects = /* @__PURE__ */ new Set();
  let total = 0;
  for (const a of snapshot.assets) {
    const match = typeof a.object_path === "string" ? objectPath.exec(a.object_path) : null;
    if (!match || match[1] !== a.owner_context_id || match[2] !== a.id || a.bucket_id !== MEDIA_BUCKET || !digest.test(a.sha256) || !Number.isSafeInteger(a.byte_size) || a.byte_size < 1 || a.byte_size > MAX_MEDIA_BYTES || assets.has(a.object_path) || !["ready", "reserved", "failed", "removing"].includes(a.state)) throw new Error("Invalid saved media ownership or integrity metadata.");
    assets.set(a.object_path, a);
  }
  const result = snapshot.objects.map((o) => {
    const match = typeof o.name === "string" ? objectPath.exec(o.name) : null;
    const size = typeof o.metadata?.size === "number" ? o.metadata.size : NaN;
    if (o.bucket_id === MEDIA_BUCKET && uuid2.test(o.id) && isStorageFolderMarker(o.name) && size === 0 && o.metadata?.mimetype === "application/octet-stream") {
      if (objects.has(o.name) || assets.has(o.name)) throw new Error("Invalid folder marker recovery metadata.");
      objects.add(o.name);
      return { id: o.id, path: o.name, byte_size: 0, sha256: sha(Buffer.alloc(0)), source: "orphan" };
    }
    if (o.bucket_id !== MEDIA_BUCKET || !uuid2.test(o.id) || !match || objects.has(o.name) || !Number.isSafeInteger(size) || size < 1 || size > MAX_MEDIA_BYTES || o.metadata?.mimetype !== `image/${match[3]}`) throw new Error("Unsupported Storage object; recovery cannot omit it.");
    objects.add(o.name);
    total += size;
    if (total > MAX_TOTAL_BYTES) throw new Error("Storage recovery exceeds the bounded archive capacity.");
    const a = assets.get(o.name);
    if (a && a.byte_size !== size) throw new Error("Storage size differs from the saved media reservation.");
    return { id: match[2], path: o.name, byte_size: size, sha256: a?.sha256, source: a ? "asset" : "orphan" };
  });
  for (const a of assets.values()) if (a.state === "ready" && !objects.has(a.object_path)) throw new Error("Ready media is missing its Storage object.");
  if (new Set(result.map((o) => o.id)).size !== result.length) throw new Error("Storage recovery object IDs are ambiguous.");
  return result;
}
function privateRecoveryDirectory(directory) {
  const s = fs2.lstatSync(directory);
  if (!s.isDirectory() || s.isSymbolicLink() || (s.mode & 63) !== 0) throw new Error("Recovery directory must be private and regular.");
}
function readPrivateRecoveryFile(file, maximum) {
  const fd = fs2.openSync(file, fs2.constants.O_RDONLY | fs2.constants.O_NOFOLLOW);
  try {
    const s = fs2.fstatSync(fd);
    if (!s.isFile() || (s.mode & 63) !== 0 || s.size > maximum) throw new Error("Private bounded recovery file required.");
    const bytes = fs2.readFileSync(fd);
    if (bytes.length !== s.size || bytes.length > maximum) throw new Error("Recovery file changed during reading.");
    return bytes;
  } finally {
    fs2.closeSync(fd);
  }
}
function open(bytes, key, aad) {
  if (bytes.length < 33 || !bytes.subarray(0, 5).equals(Buffer.from("PVSB1"))) throw new Error("Invalid Storage recovery archive.");
  const c = crypto2.createDecipheriv("aes-256-gcm", key, bytes.subarray(5, 17));
  c.setAAD(Buffer.from(aad));
  c.setAuthTag(bytes.subarray(-16));
  return Buffer.concat([c.update(bytes.subarray(17, -16)), c.final()]);
}
function manifestAAD(id, b) {
  return "pinevela:storage:manifest:" + id + ":" + canonical(b);
}
function objectAAD(id, b, inventory, e) {
  return "pinevela:storage:object:" + id + ":" + canonical(b) + ":" + inventory + ":" + canonical(e);
}
function verifyDirectory(directory, id, binding, expected, onObject) {
  privateRecoveryDirectory(directory);
  validBinding(binding);
  if (!uuid2.test(id)) throw new Error("Invalid Storage recovery ID.");
  const key = readPrivateRecoveryFile(path.join(directory, "key"), 32);
  if (key.length !== 32) throw new Error("Invalid Storage recovery key.");
  try {
    const bytes = open(readPrivateRecoveryFile(path.join(directory, "manifest.pvsb"), MAX_MANIFEST_BYTES + 33), key, manifestAAD(id, binding));
    let m;
    try {
      m = JSON.parse(bytes.toString());
    } finally {
      bytes.fill(0);
    }
    if (m.version !== 1 || m.id !== id || canonical(m.binding) !== canonical(binding) || m.inventoryDigest !== storageSnapshotDigest(expected) || storageSnapshotDigest(m.snapshot) !== m.inventoryDigest || !Array.isArray(m.entries)) throw new Error("Storage recovery does not match the database checkpoint.");
    const originals = storageRecoveryObjects(expected);
    if (m.entries.length !== originals.length) throw new Error("Incomplete Storage recovery archive.");
    const files = /* @__PURE__ */ new Set(["key", "manifest.pvsb"]);
    let total = 0;
    for (let i = 0; i < originals.length; i++) {
      const e = m.entries[i], o = originals[i];
      if (!e || e.id !== o.id || e.path !== o.path || e.byte_size !== o.byte_size || e.source !== o.source || !digest.test(e.sha256) || o.sha256 && e.sha256 !== o.sha256 || e.file !== o.id + ".pvblob" || files.has(e.file)) throw new Error("Storage recovery object manifest mismatch.");
      files.add(e.file);
      const data = open(readPrivateRecoveryFile(path.join(directory, e.file), MAX_MEDIA_BYTES + 33), key, objectAAD(id, binding, m.inventoryDigest, e));
      try {
        if (data.length !== e.byte_size || sha(data) !== e.sha256) throw new Error("Storage recovery object integrity failed.");
        total += data.length;
        onObject?.(e, data);
      } finally {
        data.fill(0);
      }
    }
    if (fs2.readdirSync(directory).some((f) => !files.has(f))) throw new Error("Unexpected Storage recovery files.");
    return { objects: originals.length, orphanObjects: originals.filter((e) => e.source === "orphan").length, folderMarkers: originals.filter((e) => isStorageFolderMarker(e.path)).length, bytes: total, inventoryDigest: m.inventoryDigest };
  } finally {
    key.fill(0);
  }
}
function verifyStorageBackup(directory, id, binding, snapshot, onObject) {
  privateRecoveryDirectory(directory);
  if (!uuid2.test(id)) throw new Error("Invalid Storage recovery ID.");
  return verifyDirectory(path.join(directory, id + ".pvstorage"), id, binding, snapshot, onObject);
}

// supabase/adminGovernance.ts
function deniedApprovalKey(grant) {
  if (!grant.allowed) throw new ApiError(grant.locked ? 429 : 403, grant.locked ? "Too many approval-key attempts. Wait 15 minutes." : "Enter your current separate approval key.", grant.locked ? "approval_key_locked" : "approval_key_required");
}
async function requireApprovalGrant(c, a, grant) {
  await requireAdministrator(c, a);
  deniedApprovalKey(grant);
  if (!(await c.query(`select context_id from private.admin_secrets where context_id=$1 and approval_key_hash is not null
    and approval_key_version=$2 and (locked_until is null or locked_until<=clock_timestamp()) for share`, [a.contextId, grant.version])).rowCount)
    throw new ApiError(403, "Your approval authorization changed. Enter your current key again.");
  await c.query("select set_config('pinevela.approval_key_version',$1,true)", [grant.version]);
}

// scripts/lib/residence-recovery.ts
import path4 from "node:path";
import crypto5 from "node:crypto";

// scripts/lib/storage-checkpoint.ts
import fs4 from "node:fs";
import path3 from "node:path";
import crypto4 from "node:crypto";
import { Pool as Pool2 } from "pg";

// scripts/lib/isolated-postgres.ts
import fs3 from "node:fs";
import path2 from "node:path";
import crypto3 from "node:crypto";
import { spawnSync } from "node:child_process";
function privateBytes(file) {
  const stat = fs3.lstatSync(file);
  if (!stat.isFile() || stat.mode & 63) throw new Error("Private regular backup file required.");
  const fd = fs3.openSync(file, fs3.constants.O_RDONLY | fs3.constants.O_NOFOLLOW);
  try {
    return fs3.readFileSync(fd);
  } finally {
    fs3.closeSync(fd);
  }
}
function decryptedCheckpoint(id) {
  if (!/^[0-9a-f-]{36}$/.test(id)) throw new Error("Pass a backup UUID.");
  const directory = path2.resolve(".security/migration-reset"), metadata = JSON.parse(privateBytes(path2.join(directory, id + ".json")).toString());
  if (!metadata.accessControlIncluded || !metadata.sourceSchemas?.includes("private")) throw new Error("Full privilege-aware checkpoint required.");
  const saved = privateBytes(path2.join(directory, id + ".pvpg")), key = privateBytes(path2.join(directory, id + ".key"));
  if (key.length !== 32 || !saved.subarray(0, 5).equals(Buffer.from("PVPG1"))) throw new Error("Invalid encrypted archive.");
  const decipher = crypto3.createDecipheriv("aes-256-gcm", key, saved.subarray(5, 17));
  decipher.setAuthTag(saved.subarray(-16));
  const decrypted = Buffer.concat([decipher.update(saved.subarray(17, -16)), decipher.final()]);
  key.fill(0);
  if (crypto3.createHash("sha256").update(decrypted).digest("hex") !== metadata.dumpSha256) throw new Error("Archive integrity failed.");
  return decrypted;
}
async function withIsolatedBackup(id, work, options = {}) {
  const decrypted = decryptedCheckpoint(id), directory = path2.resolve(".security/migration-reset");
  const root = path2.join("/tmp", "pv-orders-" + crypto3.randomUUID()), cluster = path2.join(root, "postgres");
  fs3.mkdirSync(root, { mode: 448 });
  const env = { ...process.env, PGHOST: root, PGPORT: "6543", PGDATABASE: "postgres", PGUSER: "pv_restore", PGPASSWORD: "", PGSSLMODE: "disable" };
  function command(name, args2, input) {
    const result = spawnSync(path2.join("/usr/lib/postgresql/18/bin", name), args2, { input, env, timeout: 6e4, maxBuffer: 64 * 1024 * 1024 });
    if (result.status !== 0) {
      fs3.writeFileSync(path2.join(directory, id + ".order-test-failure.log"), result.stderr || Buffer.from("Local PostgreSQL command failed."), { mode: 384 });
      throw new Error("Isolated PostgreSQL " + name + " failed; diagnostics saved privately.");
    }
    return result.stdout;
  }
  let started2 = false;
  try {
    command("initdb", ["-D", cluster, "--username=pv_restore", "--auth-local=trust", "--auth-host=reject", "--no-instructions"]);
    fs3.appendFileSync(path2.join(cluster, "postgresql.conf"), "\nlisten_addresses = ''\nunix_socket_directories = '" + root + "'\nport = 6543\n", { mode: 384 });
    command("pg_ctl", ["-D", cluster, "-l", path2.join(root, "postgres.log"), "-w", "start"]);
    started2 = true;
    command("psql", ["-X", "-v", "ON_ERROR_STOP=1"], `create schema extensions;
      create extension if not exists "uuid-ossp" with schema extensions;
      create extension if not exists pgcrypto with schema extensions;
      create extension if not exists pg_trgm with schema extensions;
      do $$ declare name text; begin foreach name in array array['anon','authenticated','service_role','authenticator','supabase_auth_admin','supabase_storage_admin','postgres','supabase_admin','pinevela_backend','pinevela_catalog','dashboard_user'] loop
        if not exists(select 1 from pg_roles where rolname=name) then execute format('create role %I nologin',name); end if;
      end loop; end $$; alter role pinevela_catalog nologin noinherit nobypassrls; grant pinevela_catalog to postgres;
    grant authenticated to pinevela_backend; grant pinevela_backend to postgres;`);
    command("pg_restore", ["--dbname=postgres", "--clean", "--if-exists", "--no-owner", "--single-transaction"], decrypted);
    decrypted.fill(0);
    if (options.applicationCheckpoint) {
      const application = decryptedCheckpoint(options.applicationCheckpoint);
      const authFingerprint = () => command("psql", ["-X", "-q", "-t", "-A", "-v", "ON_ERROR_STOP=1"], `select md5(jsonb_build_object(
        'users',(select jsonb_agg(to_jsonb(t) order by id) from auth.users t),
        'identities',(select jsonb_agg(to_jsonb(t) order by id) from auth.identities t),
        'sessions',(select jsonb_agg(to_jsonb(t) order by id) from auth.sessions t))::text);`).toString().trim();
      const before = authFingerprint();
      try {
        command("psql", ["-X", "-v", "ON_ERROR_STOP=1"], "drop schema private cascade; drop schema public cascade; create schema public; create schema private; revoke all on schema private from public;");
        command("pg_restore", ["--dbname=postgres", "--no-owner", "--single-transaction", "--schema=public", "--schema=private"], application);
        const schemaAcl = command("pg_restore", ["--list"], application).toString().split("\n").filter((line) => /\bACL - SCHEMA (public|private)\b/.test(line)).join("\n") + "\n";
        if (!schemaAcl.trim()) throw new Error("Archived application schema privileges required.");
        const aclFile = path2.join(root, "schema-acl.list");
        fs3.writeFileSync(aclFile, schemaAcl, { mode: 384 });
        command("pg_restore", ["--dbname=postgres", "--no-owner", "--single-transaction", "--use-list=" + aclFile], application);
        const storagePolicies = command("pg_restore", ["--list"], application).toString().split("\n").filter((line) => /\bPOLICY storage objects pinevela_owned_object_read\b/.test(line)).join("\n") + "\n";
        if (!storagePolicies.trim()) throw new Error("Archived owned-object policy required.");
        const policyFile = path2.join(root, "storage-policy.list");
        fs3.writeFileSync(policyFile, storagePolicies, { mode: 384 });
        command("pg_restore", ["--dbname=postgres", "--no-owner", "--single-transaction", "--use-list=" + policyFile], application);
        command("psql", ["-X", "-v", "ON_ERROR_STOP=1"], `create trigger pinevela_auth_user_created after insert on auth.users
          for each row execute function private.create_primary_profile();`);
        if (before !== authFingerprint()) throw new Error("Rebased fixture changed genuine Auth records.");
      } finally {
        application.fill(0);
      }
    }
    return await work({ host: root, port: 6543, database: "postgres", user: "pv_restore", password: "", ssl: false, max: 8, connectionTimeoutMillis: 1e4, statement_timeout: 15e3, query_timeout: 3e4 });
  } finally {
    try {
      if (started2) command("pg_ctl", ["-D", cluster, "-m", "immediate", "-w", "stop"]);
    } finally {
      decrypted.fill(0);
      fs3.rmSync(root, { recursive: true, force: true });
    }
  }
}

// scripts/lib/storage-checkpoint.ts
function storageArchiveRoot() {
  for (const dir of [".security", ".security/migration-reset"]) privateRecoveryDirectory(path3.resolve(dir));
  const directory = path3.resolve(".security/migration-reset/storage");
  if (!fs4.existsSync(directory)) fs4.mkdirSync(directory, { mode: 448 });
  privateRecoveryDirectory(directory);
  return directory;
}
async function storageCheckpoint(checkpointId, inspect) {
  if (!/^[a-f0-9]{8}(?:-[a-f0-9]{4}){3}-[a-f0-9]{12}$/.test(checkpointId)) throw new Error("Pass the database checkpoint UUID.");
  for (const dir of [".security", ".security/migration-reset"]) privateRecoveryDirectory(path3.resolve(dir));
  const directory = path3.resolve(".security/migration-reset");
  const metadata = JSON.parse(readPrivateRecoveryFile(path3.join(directory, checkpointId + ".json"), 1024 * 1024).toString());
  const rehearsal = JSON.parse(readPrivateRecoveryFile(path3.join(directory, checkpointId + ".restore.json"), 1024 * 1024).toString());
  if (!metadata.accessControlIncluded || !metadata.encrypted || !metadata.decryptedRoundTripVerified || !["auth", "public", "private", "storage"].every((s) => metadata.sourceSchemas?.includes(s)) || !rehearsal.isolatedLocalRestorePassed || rehearsal.archiveSha256 !== metadata.dumpSha256 || metadata.serverSecrets && !rehearsal.serverPinKeyVerified) throw new Error("A fully rehearsed privilege-aware database checkpoint is required.");
  const binding = { projectRef: metadata.projectRef, checkpointId, dumpSha256: metadata.dumpSha256 };
  const snapshot = await withIsolatedBackup(checkpointId, async (config) => {
    const pool = new Pool2(config), client = await pool.connect();
    try {
      return { catalog: await readStorageSnapshot(client), inspection: inspect ? await inspect(client) : void 0 };
    } finally {
      client.release();
      await pool.end();
    }
  });
  return { binding, snapshot: snapshot.catalog, inspection: snapshot.inspection, createdAt: metadata.createdAt };
}
function reconstructStorageBackup(archiveId, binding, snapshot) {
  const temporary = fs4.mkdtempSync(path3.join("/tmp", "pv-storage-restore-"));
  fs4.chmodSync(temporary, 448);
  try {
    return verifyStorageBackup(storageArchiveRoot(), archiveId, binding, snapshot, (entry, bytes) => {
      const file = path3.join(temporary, entry.id + (isStorageFolderMarker(entry.path) ? ".folder-marker" : entry.path.endsWith(".webp") ? ".webp" : ".png")), fd = fs4.openSync(file, fs4.constants.O_CREAT | fs4.constants.O_EXCL | fs4.constants.O_WRONLY | fs4.constants.O_NOFOLLOW, 384);
      try {
        fs4.writeFileSync(fd, bytes);
        fs4.fsyncSync(fd);
      } finally {
        fs4.closeSync(fd);
      }
      const recovered = fs4.readFileSync(file);
      try {
        if (recovered.length !== entry.byte_size || crypto4.createHash("sha256").update(recovered).digest("hex") !== entry.sha256) throw new Error("Reconstructed photograph integrity failed.");
      } finally {
        recovered.fill(0);
      }
    });
  } finally {
    fs4.rmSync(temporary, { recursive: true, force: true });
  }
}

// scripts/lib/residence-recovery.ts
var checked = Symbol("verified-residence-recovery");
async function recoveryPreparation(c, proposalId) {
  const result = (await c.query(`select jsonb_build_object('id',f.id,'proposalId',p.id,'founderId',f.founder_context_id,'createdAt',f.created_at,
    'state',f.state,'scopeDigest',f.preview_digest,'hostelName',p.preview->>'hostelName','current',private.residence_review_current(p),
    'quorum',private.residence_review_quorum(p.id),'status',p.status) as pause
    from private.residence_deletion_preparations f join public.admin_proposals p on p.id=f.proposal_id where p.id=$1`, [uuid(proposalId)])).rows[0]?.pause;
  if (!result) throw new ApiError(409, "Start a keyed founder preparation pause before recording backups.", "residence_preparation_missing");
  if (result.state !== "frozen" || result.status !== "approved" || !result.current || !result.quorum)
    throw new ApiError(409, "The preparation pause or its approved consent changed.", "residence_preparation_changed");
  return result;
}
async function verifyResidenceRecoveryFiles(proposalId, checkpointId, storageArchiveId) {
  uuid(proposalId);
  uuid(checkpointId);
  uuid(storageArchiveId);
  const { binding, snapshot, inspection: pause2, createdAt } = await storageCheckpoint(checkpointId, (c) => recoveryPreparation(c, proposalId));
  if (!pause2 || !Number.isFinite(Date.parse(createdAt)) || Date.parse(createdAt) < Date.parse(pause2.createdAt) || Date.parse(createdAt) > Date.now())
    throw new ApiError(409, "The checkpoint must include the actual current preparation pause.");
  const reconstructed = reconstructStorageBackup(storageArchiveId, binding, snapshot);
  const manifest = readPrivateRecoveryFile(path4.join(storageArchiveRoot(), storageArchiveId + ".pvstorage", "manifest.pvsb"), 32 * 1024 * 1024 + 33);
  return Object.freeze({ [checked]: true, pause: pause2, snapshot, evidence: {
    preparation_id: pause2.id,
    checkpoint_id: binding.checkpointId,
    storage_archive_id: storageArchiveId,
    project_ref: binding.projectRef,
    dump_sha256: binding.dumpSha256,
    storage_inventory_digest: reconstructed.inventoryDigest,
    manifest_sha256: crypto5.createHash("sha256").update(manifest).digest("hex"),
    scope_digest: pause2.scopeDigest,
    preparation_created_at: pause2.createdAt,
    checkpoint_created_at: createdAt,
    objects: reconstructed.objects,
    bytes: reconstructed.bytes
  } });
}
async function recordResidenceRecovery(c, verified, projectRef) {
  if (verified?.[checked] !== true) throw new ApiError(409, "Actual recovery archives must be verified first.");
  if (verified.evidence.project_ref !== projectRef) throw new ApiError(409, "Recovery archives belong to another project.");
  await c.query("select pg_advisory_xact_lock(hashtextextended('residence-deletion-freeze',0))");
  await c.query("select pg_advisory_xact_lock(hashtextextended('platform-settings',0))");
  const live = await recoveryPreparation(c, verified.pause.proposalId);
  if (["id", "founderId", "createdAt", "scopeDigest"].some((k) => live[k] !== verified.pause[k]))
    throw new ApiError(409, "The archived preparation does not match the live pause.");
  if (storageSnapshotDigest(await readStorageSnapshot(c)) !== verified.evidence.storage_inventory_digest)
    throw new ApiError(409, "Storage changed after the checkpoint. Prepare and restore a fresh backup.");
  const nativeDigest = (await c.query("select private.residence_recovery_catalog_digest() as digest")).rows[0].digest;
  const evidence = { ...verified.evidence, native_catalog_digest: nativeDigest };
  const normalized = (await c.query("select to_jsonb(r)-'verified_at' as proof from jsonb_populate_record(null::private.residence_recovery_evidence,$1) r", [JSON.stringify(evidence)])).rows[0].proof;
  const saved = (await c.query("select to_jsonb(r)-'verified_at' as proof,verified_at from private.residence_recovery_evidence r where preparation_id=$1", [live.id])).rows[0];
  if (saved) {
    if (canonical(saved.proof) !== canonical(normalized))
      throw new ApiError(409, "A different recovery archive is already recorded for this pause.");
    return { success: true, noChange: true, preparationId: live.id, verifiedAt: saved.verified_at };
  }
  await c.query("select set_config('pinevela.residence_recovery_checked',$1::jsonb::text,true)", [JSON.stringify(normalized)]);
  const receipt = (await c.query(`insert into private.residence_recovery_evidence(preparation_id,checkpoint_id,storage_archive_id,project_ref,dump_sha256,
    storage_inventory_digest,native_catalog_digest,manifest_sha256,scope_digest,preparation_created_at,checkpoint_created_at,objects,bytes)
    select preparation_id,checkpoint_id,storage_archive_id,project_ref,dump_sha256,storage_inventory_digest,native_catalog_digest,manifest_sha256,
    scope_digest,preparation_created_at,checkpoint_created_at,objects,bytes from jsonb_populate_record(null::private.residence_recovery_evidence,$1)
    returning verified_at`, [JSON.stringify(evidence)])).rows[0];
  const admins = (await c.query("select m.context_id from public.admin_memberships m join public.account_contexts x on x.id=m.context_id where m.status='active' and x.status='active'")).rows.map((r) => r.context_id);
  await notify(c, admins, {
    category: "admin_governance",
    title: "Residence preparation backups verified",
    message: `${live.hostelName}: recovery backups were verified for the paused review. Deletion remains unavailable.`,
    link: "governance"
  });
  await c.query("insert into private.audit_events(event_type,resource_type,resource_id) values('residence_recovery_verified','residence_preparation',$1)", [live.id]);
  return { success: true, noChange: false, preparationId: live.id, verifiedAt: receipt.verified_at };
}

// scripts/lib/residence-cleanup.ts
async function recordResidenceCleanupPlan(c, verified, projectRef) {
  await recordResidenceRecovery(c, verified, projectRef);
  const id = verified.pause.id;
  const proof = (await c.query(`with derived as materialized(select private.residence_cleanup_preview($1::uuid) as plan)
    select jsonb_build_object('preparation_id',$1::uuid,
    'native_catalog_digest',private.residence_recovery_catalog_digest(),
    'plan',plan,'plan_digest',encode(sha256(convert_to(plan::text,'UTF8')),'hex')) as proof from derived`, [id])).rows[0].proof;
  const saved = (await c.query("select to_jsonb(t)-'created_at' as proof,created_at from private.residence_cleanup_plans t where preparation_id=$1", [id])).rows[0];
  if (saved) {
    if (canonical(saved.proof) !== canonical(proof)) throw new ApiError(409, "Cleanup references changed. Cancel the pause and review a fresh scope.");
    return { success: true, noChange: true, preparationId: id, plannedAt: saved.created_at, removeCount: proof.plan.removeCount, retainCount: proof.plan.retainCount };
  }
  await c.query("select set_config('pinevela.residence_cleanup_checked',$1::jsonb::text,true)", [JSON.stringify(proof)]);
  const row = (await c.query(`insert into private.residence_cleanup_plans(preparation_id,native_catalog_digest,plan,plan_digest)
    select preparation_id,native_catalog_digest,plan,plan_digest from jsonb_populate_record(null::private.residence_cleanup_plans,$1)
    returning created_at`, [JSON.stringify(proof)])).rows[0];
  const admins = (await c.query("select m.context_id from public.admin_memberships m join public.account_contexts x on x.id=m.context_id where m.status='active' and x.status='active'")).rows.map((r) => r.context_id);
  await notify(c, admins, {
    category: "admin_governance",
    title: "Residence Storage cleanup planned",
    message: `${verified.pause.hostelName}: ${proof.plan.removeCount} exclusive housing images are planned for cleanup; ${proof.plan.retainCount} images are retained. No records or images were deleted.`,
    link: "governance"
  });
  await c.query("insert into private.audit_events(event_type,resource_type,resource_id) values('residence_cleanup_planned','residence_preparation',$1)", [id]);
  return { success: true, noChange: false, preparationId: id, plannedAt: row.created_at, removeCount: proof.plan.removeCount, retainCount: proof.plan.retainCount };
}

// scripts/lib/residence-execution.ts
async function executeResidenceCore(c, actor, grant, verified, projectRef) {
  await requireApprovalGrant(c, actor, grant);
  if (!(await c.query("select 1 from public.admin_memberships where context_id=$1 and slot=1 and status='active'", [actor.contextId])).rowCount)
    throw new ApiError(403, "Only the founder can execute reviewed residence removal.");
  await recordResidenceCleanupPlan(c, verified, projectRef);
  const authorization = (await c.query(`select a.id from private.residence_execution_authorizations a
  where a.preparation_id=$1 and a.founder_context_id=$2 and a.auth_user_id=$3 and a.session_id=$4
   and a.approval_key_version=$5 and private.residence_execution_authorization_current(a)
  order by a.created_at desc limit 1`, [verified.pause.id, actor.contextId, actor.authUserId, actor.sessionId, grant.version])).rows[0];
  if (!authorization) throw new ApiError(409, "Give fresh final founder consent for the exact saved recovery plan.");
  const receipt = (await c.query("select to_jsonb(r)-'verified_at' as proof from private.residence_recovery_evidence r where preparation_id=$1", [verified.pause.id])).rows[0];
  await c.query("select set_config('pinevela.residence_execution_recovery_checked',$1::jsonb::text,true)", [JSON.stringify(receipt.proof)]);
  await c.query("select set_config('pinevela.residence_execution_confirmation','DELETE APPROVED HOSTEL',true)");
  const result = (await c.query("select private.run_residence_execution($1) as id", [authorization.id])).rows[0];
  const tasks = Number((await c.query("select count(*) from private.residence_storage_cleanup_tasks where execution_id=$1", [result.id])).rows[0].count);
  return { success: true, executionId: result.id, status: "executed", storageCleanup: tasks ? "queued" : "not_required", cleanupTasks: tasks, providerObjectsRemoved: 0 };
}
async function verifyResidenceExecutionFiles(db2, actor, grant, proposalId) {
  const target = uuid(proposalId);
  const receipt = await db2.authorizedSystem(actor, ["admin"], async (c) => {
    await requireApprovalGrant(c, actor, grant);
    if (!(await c.query("select 1 from public.admin_memberships where context_id=$1 and slot=1 and status='active'", [actor.contextId])).rowCount)
      throw new ApiError(403, "Only the founder can execute reviewed residence removal.");
    const saved = (await c.query(`select r.checkpoint_id,r.storage_archive_id from private.residence_recovery_evidence r
   join private.residence_deletion_preparations f on f.id=r.preparation_id where f.proposal_id=$1 and f.state='frozen'`, [target])).rows[0];
    if (!saved) throw new ApiError(409, "A reviewed pause and verified recovery receipt are required.");
    return saved;
  });
  return verifyResidenceRecoveryFiles(target, receipt.checkpoint_id, receipt.storage_archive_id);
}

// scripts/lib/residence-execution-worker.ts
async function processResidenceExecutionRequest(db2, requestId, projectRef) {
  const id = uuid(requestId), lock = await db2.pool.connect();
  let held = false;
  try {
    held = (await lock.query("select pg_try_advisory_lock(hashtextextended('residence-execution-request:'||$1::text,0)) as held", [id])).rows[0].held;
    if (!held) return { success: true, skipped: true };
    const request = (await db2.pool.query(`select r.*,private.residence_execution_request_current(r) as current
   from private.residence_execution_requests r where r.id=$1`, [id])).rows[0];
    if (!request) throw new ApiError(404, "Reviewed execution request not found.");
    if (request.state === "completed") return { success: true, noChange: true, status: "executed", executionId: request.execution_id };
    if (request.state === "invalidated") return { success: true, skipped: true, status: "invalidated" };
    if (!request.current) return await db2.system(async (c) => {
      await c.query("select pg_advisory_xact_lock(hashtextextended('residence-deletion-freeze',0))");
      await c.query("select pg_advisory_xact_lock(hashtextextended('platform-settings',0))");
      const changed = await c.query(`update private.residence_execution_requests r set state='invalidated'
    where id=$1 and state='requested' and not private.residence_execution_request_current(r) returning failure_code`, [id]);
      if (!changed.rowCount) return { success: true, skipped: true };
      const admins = (await c.query("select m.context_id from public.admin_memberships m join public.account_contexts x on x.id=m.context_id where m.status='active' and x.status='active'")).rows.map((r) => r.context_id);
      await notify(c, admins, {
        category: "admin_governance",
        title: "Reviewed residence deletion request closed",
        message: "The requested deletion lost current founder consent. No records were deleted; give fresh consent or cancel preparation to resume housing.",
        link: "governance"
      });
      await c.query("insert into private.audit_events(event_type,resource_type,resource_id) values('residence_execution_request_invalidated','admin_proposal',$1)", [request.proposal_id]);
      return { success: true, status: "invalidated" };
    });
    const actor = { authUserId: request.auth_user_id, sessionId: request.session_id, contextId: request.founder_context_id, kind: "admin" };
    const grant = { allowed: true, version: request.approval_key_version };
    const verified = await verifyResidenceExecutionFiles(db2, actor, grant, request.proposal_id);
    return await db2.authorizedSystem(actor, ["admin"], async (c) => {
      const current = (await c.query(`select r.authorization_id from private.residence_execution_requests r
    where id=$1 and private.residence_execution_request_current(r) for update`, [id])).rows[0];
      if (!current || current.authorization_id !== request.authorization_id) throw new ApiError(409, "The requested consent expired or changed.");
      const result = await executeResidenceCore(c, actor, grant, verified, projectRef);
      const changed = await c.query("update private.residence_execution_requests set state='completed',execution_id=$2 where id=$1 and state='requested'", [id, result.executionId]);
      if (changed.rowCount !== 1) throw new ApiError(409, "The execution request changed.");
      return result;
    }, false, false, true);
  } finally {
    if (held) await lock.query("select pg_advisory_unlock(hashtextextended('residence-execution-request:'||$1::text,0))", [id]).catch(() => void 0);
    lock.release(true);
  }
}

// scripts/lib/residence-storage-worker.ts
import crypto6 from "node:crypto";
import path5 from "node:path";
var prepared = Symbol("prepared-residence-storage");
var missing = Symbol("observed-residence-storage-absence");
async function nativeTask(db2, asset) {
  return db2.system(async (c) => {
    const row = (await c.query(`select t.candidate,e.proposal_id,e.preparation_id,e.founder_context_id,e.resources,
   r.checkpoint_id,r.storage_archive_id,to_jsonb(r)-'verified_at' as recovery,
   jsonb_build_object('id',o.id,'version',o.version,'updatedAt',o.updated_at) as object
   from private.residence_storage_cleanup_tasks t join private.residence_executions e on e.id=t.execution_id
   join private.residence_recovery_evidence r on r.preparation_id=e.preparation_id
   left join storage.objects o on o.name=t.candidate->>'path' and o.bucket_id=t.candidate->>'bucket'
   where t.asset_id=$1 and private.residence_cleanup_task_valid(t.asset_id)`, [asset])).rows[0];
    if (!row) throw new ApiError(409, "An exact completed reviewed cleanup task is required.");
    if (!row.object?.id) row.object = null;
    return row;
  });
}
async function claimResidenceStorageTask(db2, asset) {
  return db2.system(async (c) => {
    const row = (await c.query("select * from private.claim_residence_storage_cleanup($1)", [uuid(asset)])).rows[0];
    return row?.id ? row : null;
  });
}
async function currentLease(db2, lease, states = ["deleting"]) {
  return db2.system(async (c) => {
    const row = (await c.query(`select id from private.residence_storage_cleanup_attempts where id=$1 and token=$2 and asset_id=$3
   and state=any($4::text[]) and expires_at>clock_timestamp() and private.residence_cleanup_unshared(asset_id)`, [lease.id, lease.token, lease.asset_id, states])).rows[0];
    if (!row) throw new ApiError(409, "Cleanup lease expired or references changed.");
  });
}
function providerMatches(info, row) {
  return info.id === row.object?.id && info.version === row.object?.version && info.name === row.candidate.path && info.bucket_id === row.candidate.bucket && Number(info.size) === row.candidate.bytes && info.content_type === "image/png" && Date.parse(String(info.last_modified)) === Date.parse(row.object.updatedAt);
}
async function prepareResidenceStorageTask(db2, lease) {
  await currentLease(db2, lease, ["claimed"]);
  const row = await nativeTask(db2, lease.asset_id);
  const { binding, snapshot, inspection, createdAt } = await storageCheckpoint(row.checkpoint_id, async (c) => (await c.query(`
  select f.id,f.proposal_id,f.founder_context_id,to_jsonb(f.created_at) as created_at,f.preview_digest,f.state,p.status,p.kind,p.baseline_digest,
   p.preview->'resources' as resources from private.residence_deletion_preparations f
   join public.admin_proposals p on p.id=f.proposal_id where f.id=$1 and p.id=$2`, [row.preparation_id, row.proposal_id])).rows[0]);
  if (!inspection || inspection.state !== "frozen" || inspection.status !== "approved" || inspection.kind !== "residence_deletion" || inspection.founder_context_id !== row.founder_context_id || inspection.preview_digest !== row.recovery.scope_digest || inspection.baseline_digest !== row.recovery.scope_digest || canonical(inspection.resources) !== canonical(row.resources))
    throw new ApiError(409, "The archive does not contain the exact original approved scope.");
  const reconstructed = reconstructStorageBackup(row.storage_archive_id, binding, snapshot);
  const manifest = readPrivateRecoveryFile(path5.join(storageArchiveRoot(), row.storage_archive_id + ".pvstorage", "manifest.pvsb"), 32 * 1024 * 1024 + 33);
  const evidence = {
    preparation_id: inspection.id,
    checkpoint_id: binding.checkpointId,
    storage_archive_id: row.storage_archive_id,
    project_ref: binding.projectRef,
    dump_sha256: binding.dumpSha256,
    storage_inventory_digest: reconstructed.inventoryDigest,
    manifest_sha256: crypto6.createHash("sha256").update(manifest).digest("hex"),
    scope_digest: inspection.preview_digest,
    preparation_created_at: inspection.created_at,
    checkpoint_created_at: createdAt,
    objects: reconstructed.objects,
    bytes: reconstructed.bytes
  };
  const proof = Object.fromEntries(Object.entries(row.recovery).filter(([k]) => k !== "native_catalog_digest"));
  const normalized = await db2.system(async (c) => (await c.query("select to_jsonb(r)-array['verified_at','native_catalog_digest'] as proof from jsonb_populate_record(null::private.residence_recovery_evidence,$1) r", [JSON.stringify(evidence)])).rows[0].proof);
  if (canonical(proof) !== canonical(normalized) || !snapshot.assets.some((a) => a.id === lease.asset_id && a.object_path === row.candidate.path && a.sha256 === row.candidate.sha256 && a.byte_size === row.candidate.bytes))
    throw new ApiError(409, "Exact archived cleanup bytes could not be verified.");
  const storage = new SupabaseStorage(), info = await storage.objectInfo(row.candidate.path);
  if (info) {
    if (!providerMatches(info, row)) throw new ApiError(409, "The provider object identity changed.");
    const bytes = await storage.downloadForBackup(row.candidate.path, { byte_size: row.candidate.bytes, sha256: row.candidate.sha256 }, 6e4);
    bytes.fill(0);
  } else if (row.object) throw new ApiError(409, "Provider absence disagrees with the native object catalog.");
  await db2.system(async (c) => {
    await c.query("select set_config('pinevela.residence_cleanup_token',$1,true)", [lease.token]);
    await c.query(
      "select set_config('pinevela.residence_cleanup_verified',$1::jsonb::text,true)",
      [JSON.stringify({ attemptId: lease.id, recovery: row.recovery, object: row.object })]
    );
    const updated = await c.query("update private.residence_storage_cleanup_attempts set state='deleting',object_identity=$3::jsonb where id=$1 and token=$2", [lease.id, lease.token, JSON.stringify(row.object)]);
    if (updated.rowCount !== 1) throw new ApiError(409, "Cleanup lease no longer exists.");
  });
  return Object.freeze({ [prepared]: true, lease, path: row.candidate.path, identity: row.object, sha256: row.candidate.sha256, bytes: row.candidate.bytes });
}
async function removePreparedResidenceStorageTask(db2, work) {
  if (work?.[prepared] !== true) throw new ApiError(409, "Fresh verified cleanup preparation is required.");
  await currentLease(db2, work.lease);
  const row = await nativeTask(db2, work.lease.asset_id), storage = new SupabaseStorage(), info = await storage.objectInfo(work.path);
  if (canonical(row.object) !== canonical(work.identity)) throw new ApiError(409, "The native object identity changed.");
  if (info) {
    if (!providerMatches(info, row)) throw new ApiError(409, "The provider object changed before removal.");
    const bytes = await storage.downloadForBackup(work.path, { byte_size: work.bytes, sha256: work.sha256 }, 6e4);
    bytes.fill(0);
    await currentLease(db2, work.lease);
    await storage.remove(work.path);
  }
  if (await storage.objectInfo(work.path)) throw new ApiError(503, "Storage removal is not yet confirmed.");
  return Object.freeze({ [missing]: true, work });
}
async function completeResidenceStorageTask(db2, result) {
  if (result?.[missing] !== true) throw new ApiError(409, "An actual provider absence observation is required.");
  const work = result.work;
  if (await new SupabaseStorage().objectInfo(work.path)) throw new ApiError(409, "The object is present again.");
  return db2.system(async (c) => {
    await c.query("select set_config('pinevela.residence_cleanup_token',$1,true)", [work.lease.token]);
    await c.query("select set_config('pinevela.residence_cleanup_missing',$1,true)", [work.lease.id]);
    const changed = await c.query("update private.residence_storage_cleanup_attempts set state='completed' where id=$1 and token=$2", [work.lease.id, work.lease.token]);
    if (changed.rowCount !== 1) throw new ApiError(409, "Cleanup lease no longer exists.");
    await c.query(
      "insert into private.audit_events(event_type,resource_type,resource_id,event_data) values('residence_storage_removed','media_asset',$1,$2)",
      [work.lease.asset_id, JSON.stringify({ attemptId: work.lease.id, providerAbsenceObserved: true })]
    );
    const admins = (await c.query("select m.context_id from public.admin_memberships m join public.account_contexts x on x.id=m.context_id where m.status='active' and x.status='active'")).rows.map((r) => r.context_id);
    await notify(c, admins, { category: "admin_governance", title: "Residence image cleanup confirmed", message: "An approved exclusive residence image was removed through Storage and its absence verified.", link: "governance" });
    return { success: true, assetId: work.lease.asset_id, providerAbsenceVerified: true };
  });
}
async function failResidenceStorageTask(db2, lease, code) {
  await db2.system(async (c) => {
    await c.query("select set_config('pinevela.residence_cleanup_token',$1,true)", [lease.token]);
    await c.query("update private.residence_storage_cleanup_attempts set state='failed',error_code=$3 where id=$1 and token=$2 and state in('claimed','deleting') and expires_at>clock_timestamp()", [lease.id, lease.token, code]);
  });
}
async function processResidenceStorageTask(db2, asset) {
  const lease = await claimResidenceStorageTask(db2, asset);
  if (!lease) return { claimed: false };
  try {
    const work = await prepareResidenceStorageTask(db2, lease), absence = await removePreparedResidenceStorageTask(db2, work);
    return await completeResidenceStorageTask(db2, absence);
  } catch (error) {
    await failResidenceStorageTask(db2, lease, error instanceof ApiError && error.status === 503 ? "storage_unavailable" : "verification_failed").catch(() => void 0);
    throw error;
  }
}

// scripts/lib/residence-worker-batch.ts
function residenceWorkerDiagnostic(error) {
  const root = path6.resolve(".security/migration-reset");
  privateRecoveryDirectory(path6.resolve(".security"));
  privateRecoveryDirectory(root);
  const fd = fs5.openSync(
    path6.join(root, crypto7.randomUUID() + ".residence-worker.log"),
    fs5.constants.O_CREAT | fs5.constants.O_EXCL | fs5.constants.O_WRONLY | fs5.constants.O_NOFOLLOW,
    384
  );
  try {
    fs5.writeFileSync(fd, error instanceof Error ? error.stack || error.message : "Worker failed");
    fs5.fsyncSync(fd);
  } finally {
    fs5.closeSync(fd);
  }
}
async function runResidenceWorkerBatch(db2, options) {
  const execution = { pending: 0, completed: 0, invalidated: 0, skipped: 0, failed: 0 };
  const storage = { pending: 0, completed: 0, skipped: 0, failed: 0 };
  const result = () => ({ readOnly: !options.execute, stopping: options.signal?.aborted === true, limits: { execution: 10, storage: 20 }, execution, storage });
  if (options.signal?.aborted) return result();
  const requests2 = (await db2.pool.query("select id from private.residence_execution_requests where state='requested' order by created_at,id limit 10")).rows;
  execution.pending = requests2.length;
  if (options.execute) for (const request of requests2) {
    if (options.signal?.aborted) break;
    try {
      const outcome = await processResidenceExecutionRequest(db2, request.id, options.projectRef);
      if ("skipped" in outcome || "noChange" in outcome) execution.skipped++;
      else if (outcome.status === "invalidated") execution.invalidated++;
      else execution.completed++;
    } catch (error) {
      residenceWorkerDiagnostic(error);
      execution.failed++;
    }
  }
  if (options.signal?.aborted) return result();
  const jobs = (await db2.pool.query(`select t.asset_id from private.residence_storage_cleanup_tasks t
  where not exists(select 1 from private.residence_storage_cleanup_attempts a where a.asset_id=t.asset_id and a.state='completed')
   and not exists(select 1 from private.residence_storage_cleanup_attempts a where a.asset_id=t.asset_id
    and a.state in('claimed','deleting') and a.expires_at>clock_timestamp())
  order by t.created_at,t.asset_id limit 20`)).rows;
  storage.pending = jobs.length;
  if (options.execute) for (const job of jobs) {
    if (options.signal?.aborted) break;
    try {
      const outcome = await processResidenceStorageTask(db2, job.asset_id);
      if ("claimed" in outcome) storage.skipped++;
      else storage.completed++;
    } catch (error) {
      residenceWorkerDiagnostic(error);
      storage.failed++;
    }
  }
  return result();
}

// supabase-residence-worker.ts
dotenv.config({ quiet: true });
var args = process.argv.slice(2);
if (args.some((a) => !["--execute", "--watch"].includes(a)) || new Set(args).size !== args.length) {
  console.error("Only --execute and --watch are accepted.");
  process.exit(2);
}
var execute = args.includes("--execute");
var watch = args.includes("--watch");
var stop = new AbortController();
var requestStop = () => {
  if (!stop.signal.aborted) {
    stop.abort();
    console.log(JSON.stringify({ event: "stopping", drainingCurrentJob: true }));
  }
};
process.once("SIGTERM", requestStop);
process.once("SIGINT", requestStop);
var db;
var started = false;
try {
  db = new SupabaseDatabase();
  if (!(await db.pool.query("select 1 from private.schema_migrations where version='20261012014440'")).rowCount)
    throw new Error("Apply all Supabase migrations before starting the residence worker.");
  const projectRef = new URL(process.env.SUPABASE_URL).hostname.split(".")[0];
  started = true;
  console.log(JSON.stringify({ event: "started", readOnly: !execute, watch, pollSeconds: 15 }));
  while (!stop.signal.aborted) {
    try {
      const outcome = await runResidenceWorkerBatch(db, { execute, projectRef, signal: stop.signal });
      console.log(JSON.stringify({ event: "cycle", ...outcome }));
      if (!watch && (outcome.execution.failed || outcome.storage.failed)) process.exitCode = 1;
    } catch (error) {
      residenceWorkerDiagnostic(error);
      console.error(JSON.stringify({ event: "cycle_failed", diagnosticSavedPrivately: true }));
      if (!watch) process.exitCode = 1;
    }
    if (!watch || stop.signal.aborted) break;
    try {
      await pause(15e3, void 0, { signal: stop.signal });
    } catch (error) {
      if (!stop.signal.aborted) throw error;
    }
  }
} catch (error) {
  try {
    residenceWorkerDiagnostic(error);
  } catch {
  }
  console.error(JSON.stringify({ event: started ? "worker_failed" : "startup_failed", readOnly: !execute }));
  process.exitCode = 1;
} finally {
  await db?.close();
  console.log(JSON.stringify({ event: "stopped", drained: true }));
  process.removeListener("SIGTERM", requestStop);
  process.removeListener("SIGINT", requestStop);
}
