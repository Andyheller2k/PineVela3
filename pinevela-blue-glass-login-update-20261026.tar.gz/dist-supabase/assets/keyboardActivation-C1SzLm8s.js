function a(r){r.target!==r.currentTarget||r.key!=="Enter"&&r.key!==" "||(r.preventDefault(),r.stopPropagation(),r.currentTarget.click())}export{a};
