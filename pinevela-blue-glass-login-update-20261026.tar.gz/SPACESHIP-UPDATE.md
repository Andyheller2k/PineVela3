# Apply the PineVela glass login update

This archive updates the PineVela application frontend. In phone light mode,
Login and Signup now use a translucent glass card with the same tint opacity
and blur strength as phone dark mode. Blue labels, blue buttons with white
text, and the blue lower diagonal remain. Dark and desktop appearances retain
their existing styling. Opaque accessibility/unsupported-blur fallbacks remain.

1. Upload pinevela-blue-glass-login-update-20261026.tar.gz to the existing
   Spaceship pinevela-app folder containing app.cjs and dist-supabase.
2. Extract there, allowing matching files to be overwritten and merging into
   the existing dist-supabase folder. Keep older hashed assets for open tabs;
   do not delete the folder first. index.html is the final archive member.
3. Reload the site; close and reopen an installed app if needed. Use the phone's
   Light appearance to see the new light glass card.

No Node restart, NPM Install, environment change or database migration is needed.
The archive contains no backend, app.cjs, .env, private keys, data, uploads,
node_modules or source maps. Existing hosted configuration stays as it is.

This is a separate application update from the Google branding draft ZIP.
Production frontend build and theme/UI/appearance/branding checks passed locally.
The archive has not been uploaded or deployed for you.
GLASS-LOGIN-UPDATE-MANIFEST.json lists every frontend file size and SHA-256.
